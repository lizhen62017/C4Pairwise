 ! values for bits of do_flags
  integer PROCEED; parameter(PROCEED=3)
  integer PROCEED_INDUCE; parameter(PROCEED_INDUCE=5)
  integer PROCEED_POSTINDUCE; parameter(PROCEED_POSTINDUCE=9)
  integer VALID_BIT; parameter(VALID_BIT=0)
  integer USER_BIT; parameter(USER_BIT=1)
  integer USER_INDUCE_BIT; parameter(USER_INDUCE_BIT=2)
  integer USER_POSTINDUCE_BIT; parameter(USER_POSTINDUCE_BIT=3)

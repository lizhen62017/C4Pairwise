! DIR_SUM STORAGE
_REAL_ eedtbdns,dxdr
! real part
integer leed_cub,leed_lin,ltau,mxeedtab
integer eedmeth,ee_type
common/eedctab/leed_cub,leed_lin,ltau,mxeedtab, &
      eedmeth,ee_type
common/tabpars/eedtbdns,dxdr

!+ Soon to be eliminated.
!  ^^^^^ This line was added ~7 years ago. Define 'soon' :)

logical master, master_master
common/extra_logical/master, master_master


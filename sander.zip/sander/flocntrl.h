integer do_dir,do_rec,do_adj,do_self
#define BC_FLOCNTRL 14
integer do_bond,do_angle,do_ephi,doxconst,do_cap, &
      do_14,do_tgt,do_pbdir,do_pbnp,do_pbfd
common/flocntrl/do_dir,do_rec,do_adj,do_self,do_bond, & !5
      do_angle,do_ephi,doxconst,do_cap,do_14,do_tgt, &  !11
      do_pbdir,do_pbnp,do_pbfd                          !14

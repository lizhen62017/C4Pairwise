_REAL_ boxlo,boxhi
parameter (boxlo=1.d0,boxhi=1.d3)
_REAL_ anglo,anghi
parameter (anglo=30.d0,anghi=150.d0)
integer orderlo,orderhi
parameter(orderlo=3,orderhi=25)
_REAL_ ew_coefflo,ew_coeffhi
parameter(ew_coefflo=0.1d0,ew_coeffhi=0.7d0)
integer gridlo,gridhi
parameter(gridlo=6,gridhi=2048)
_REAL_ tollo,tolhi
parameter(tollo=1.d-12,tolhi=1.d-2)
_REAL_ skinlo,skinhi
parameter(skinlo=0.d0,skinhi=5.d0)
_REAL_ denslo,denshi
parameter(denslo=100.d0,denshi=25000.d0)

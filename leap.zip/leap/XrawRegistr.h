#ifndef _XrawRegistr_h_
#define _XrawRegistr_h_


extern void XrawRegisterAll (); /* XtAppContext */

#endif /* _XrawRegistr_h_ */

/*
* SCCS_data: %Z% %M% %I% %E% %U%
******************************************************************************
	Copyright 1990, 1991, 1992, 1993, 1994 David E. Smyth

			All Rights Reserved

Permission to use, copy, modify, and distribute this software and its
documentation for any purpose and without fee is hereby granted,
provided that the above copyright notice appear in all copies and that
both that copyright notice and this permission notice appear in
supporting documentation, and that the name of David E. Smyth not be
used in advertising or publicity pertaining to distribution of the
software without specific, written prior permission.

The original proof of concept and many foundational ideas for this code
came from Martin Brunecky.  Many, many people provided further ideas
and bug fixes: too many to be enumerated here.  However, their help is
sincerely appreciated, and this code would be far less useful and
reliable if not for their input.

This software is provided as-is and without any warranty of any kind.

******************************************************************************
*/

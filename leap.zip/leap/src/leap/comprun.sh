#!/bin/bash
cd ../../../../../build && ./run_cmake && make install && cd ~/C4Pairwise/HFE_OPC_NA_CL && \
../../amber20/bin/tleap -s -f leap.in && sh sander.sh

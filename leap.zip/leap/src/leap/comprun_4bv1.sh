#!/bin/bash
cd ../../../../../build && ./run_cmake && make install && cd ~/C4Pairwise/ && ../amber20/bin/tleap -s -f tleap.in && sbatch cpu.pbs

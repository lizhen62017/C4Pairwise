/*  dummy stubs for fftw3 routines that are never called  */

void fftw_alloc_complex(){ }
void fftw_alloc_real(){ }
void fftw_destroy_plan(){ }
void fftw_execute_dft_c2r(){ }
void fftw_execute_dft_r2c(){ }
void fftw_execute_dft_c2r_3d(){ }
void fftw_execute_dft_r2c_3d(){ }
void fftw_free(){ }
void fftw_plan_many_dft_c2r(){ }
void fftw_plan_many_dft_r2c(){ }
void fftw_plan_dft_c2r_3d(){ }
void fftw_plan_dft_r2c_3d(){ }

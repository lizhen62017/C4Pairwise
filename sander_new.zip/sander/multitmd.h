#include "../include/dprec.fh"

!-------------BEGIN multitmd.h  ------------------------------------------------

!  ---Header file for multiple-target targeted molecular dyanamics
!  

! Common block containing variables relating to Multi-TMD.

integer        mtmdintreq,mtmdirlreq,lmtmd01,imtmd02,mtmdtmp01
common/mtmdstf/mtmdintreq,mtmdirlreq,lmtmd01,imtmd02,mtmdtmp01

!-------------END   multitmd.h  ------------------------------------------------

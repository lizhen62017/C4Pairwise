#include	"varArray.h"

extern VARARRAY shellVarArray;
extern VARARRAY waitCursorWindow;

#define debug_cursor 1


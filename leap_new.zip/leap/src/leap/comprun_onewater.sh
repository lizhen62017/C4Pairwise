#!/bin/bash
cd ../../../../../build && ./run_cmake && make install && cd ~/onewater/1264/opc3_Mg && sbatch run2p.slm

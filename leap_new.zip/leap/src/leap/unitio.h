/*
 *      File:   unitio.h
 *
 ************************************************************************
 *                            LEAP                                      *
 *                                                                      *
 *                   Copyright (c) 1992, 1995                           *
 *           Regents of the University of California                    *
 *                     All Rights Reserved.                             *
 *                                                                      *
 *  This software provided pursuant to a license agreement containing   *
 *  restrictions on its disclosure, duplication, and use. This software *
 *  contains confidential and proprietary information, and may not be   *
 *  extracted or distributed, in whole or in part, for any purpose      *
 *  whatsoever, without the express written permission of the authors.  *
 *  This notice, and the associated author list, must be attached to    *
 *  all copies, or extracts, of this software. Any additional           *
 *  restrictions set forth in the license agreement also apply to this  *
 *  software.                                                           *
 ************************************************************************
 *                                                                      *
 *     Designed by:    Christian Schafmeister                           *
 *     Author:         Christian Schafmeister                           *
 *                                                                      *
 *     VERSION: 1.0                                                     *
 *     Programmers:                                                     *
 *             Christian Schafmeister                                   *
 *             David Rivkin                                             *
 *                                                                      *
 *     Principal Investigator: Peter A. Kollman                         *
 *                                                                      *
 ************************************************************************
 *
 *      Description:
 *              Part of the UNIT object.
 *              All file input/output routines have been
 *              placed in the file 'unitio.c'
 *
 */

/*      Modifications induced by the implementation of the savemol2 command
*        Christine Cezard (2007) 
*        Universite de Picardie - Jules Verne, Amiens
*         http://q4md-forcefieldtools.org
*         zbUnitIOIndexBondParameters and zUnitDoAtoms are now "extern functions" 
*/ 
 
#ifndef UNITIO_H
#define UNITIO_H

/*New
typedef struct {
    CONTAINERNAMEt sName;
    CONTAINERNAMEt sPertName;
    ATOMTYPEt sType;
    ATOMTYPEt sPertType;
    int iTypeIndex;
    int iPertTypeIndex;
    int iElement;
    int iPertElement;
    double dCharge;
    double dPertCharge;
    int iResidueIndex;
    VECTOR vPos;
    VECTOR vVelocity;
    int iSequence;
    FLAGS fFlags;
    ATOM aAtom;
} SAVEATOMt; 
*/

extern BOOL     zbUnitIOLoadTables(UNIT uUnit, DATABASE db);
extern void     zUnitIOSaveTables(UNIT uUnit, DATABASE db);

extern void     zUnitIOBuildTables(UNIT uUnit, PARMLIB plParameters,
                        BOOL *bPGeneratedParameters, BOOL bPert, BOOL bCheck);
extern void     zUnitIOBuildFromTables(UNIT uUnit);
extern void     zUnitIODestroyTables(UNIT uUnit);
extern BOOL     zbUnitIOIndexBondParameters(PARMLIB plLib, UNIT uUnit, BOOL bPert);

extern BOOL     zbUNitIOIndexC4Pairwise(UNIT uUnit, double daC4Pairwise); //New
extern void     zUnitDoAtoms(UNIT uUnit, PARMLIB plParameters, RESIDUE rRes, int *iPPos, BOOL * bPFailed, BOOL bPert);
extern void     zUnitIOSaveAmberParmFormat(UNIT uUnit, FILE *fOut,
                        char *crdName, BOOL bPolar, BOOL bPert, BOOL bNetcdf, char sA[3][8], char sB[3][8], double daC4Type[8], int iC4count ); //NewT
extern void     zUnitIOSaveAmberParmFormat_old(UNIT uUnit, FILE *fOut,
                        char *crdName, BOOL bPolar, BOOL bPert, char sA[3][8], char sB[3][8], double daC4Type[8], int iC4count ); //NewT
extern void     zUnitIOSaveAmberNetcdf( UNIT uUnit, char *filename );

extern void     UnitIOSaveAmberPrep( UNIT uUnit, FILE *fOut );

//extern void     UnitIOSaveC4Type( UNIT uUnit, char *sA, char *sB, double daC4Type ); //NewT

#endif  /* UNITIO_H */

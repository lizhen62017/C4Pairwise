#ifndef _BASE_XRAY_HOST_CONTEXT_FUNCS
#define _BASE_XRAY_HOST_CONTEXT_FUNCS

#include "base_xrayHostContext.h"

void base_xrayHostContext::Init()
{

}

base_xrayHostContext::base_xrayHostContext()
{
  pbSelectionMask = NULL;
  pbSelectedAtoms = NULL;
}

base_xrayHostContext::~base_xrayHostContext()
{
  
}

#endif

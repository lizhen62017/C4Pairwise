#include "copyright.i"

//---------------------------------------------------------------------------------------------
// AMBER NVIDIA CUDA GPU IMPLEMENTATION: PMEMD VERSION
//
// July 2017, by Scott Le Grand, David S. Cerutti, Daniel J. Mermelstein, Charles Lin, and
//               Ross C. Walker
//---------------------------------------------------------------------------------------------

//---------------------------------------------------------------------------------------------
// This file is included repeatedly in kCalculatePMENonbondEnergy.cu.
// #defines: IPS_ENERGY, IPS_VIRIAL, IPS_IS_ORTHOGONAL, IPS_ATOMS_PER_WARP, IPS_MINIMIZATION
//---------------------------------------------------------------------------------------------
{ 
  // Neighbor list atom
  struct NLAtom {
    PMEFloat x;
    PMEFloat y;
    PMEFloat z;
    PMEFloat q;
    unsigned int LJID;
    unsigned int ID;
  };

  // Neighbor list force on any one atom in the neighbor list of another
  struct NLForce {
    PMEForce x;
    PMEForce y;
    PMEForce z;
  };

  // Neighbor list virial
  struct NLVirial {
    long long int vir_11;
    long long int vir_22;
    long long int vir_33;
  };

  // Neighbor list warp to group atoms for import and processing
  struct NLWarp {
    NLEntry nlEntry;
    uint pos;
    bool bHomeCell;
  };

#define PSATOMX(i) shAtom.x
#define PSATOMY(i) shAtom.y
#define PSATOMZ(i) shAtom.z
#define PSATOMQ(i) shAtom.q
#define PSATOMLJID(i) shAtom.LJID
#define PSATOMID(i) shAtom.ID

#if defined(IPS_VIRIAL) || defined(IPS_ENERGY)
  const int THREADS_PER_BLOCK = IPSNONBONDENERGY_THREADS_PER_BLOCK;
#else
  const int THREADS_PER_BLOCK = IPSNONBONDFORCES_THREADS_PER_BLOCK;
#endif

  __shared__ unsigned int sNLEntries;
#if defined(IPS_VIRIAL)
  __shared__ PMEFloat sUcellf[9];
#endif
  __shared__ unsigned int sNext[GRID];
#if (IPS_ATOMS_PER_WARP <= 16)
  __shared__ unsigned int sStart[GRID];
  __shared__ unsigned int sEnd[GRID];
#endif
  __shared__ volatile NLWarp sWarp[THREADS_PER_BLOCK / GRID];
  __shared__ volatile NLForce sForce[THREADS_PER_BLOCK];
  NLAtom shAtom;
#ifdef IPS_VIRIAL
  __shared__ volatile NLVirial sWarpVirial[THREADS_PER_BLOCK / GRID];
#endif

  // Read static data
  if (threadIdx.x == 0) {
    sNLEntries = *(cSim.pNLEntries);
  }
  if (threadIdx.x < GRID) {
    unsigned int offset = cSim.NLAtomsPerWarp * (threadIdx.x >> cSim.NLAtomsPerWarpBits);
    sNext[threadIdx.x] = ((threadIdx.x + 1) & cSim.NLAtomsPerWarpBitsMask) + offset;

#if (IPS_ATOMS_PER_WARP == 16)
    // SIZE DEPENDENT 2, 8
    sStart[threadIdx.x] = (threadIdx.x + 1 + 8*(threadIdx.x >> cSim.NLAtomsPerWarpBits)) &
                          cSim.NLAtomsPerWarpBitsMask;
    // SIZE DEPENDENT (3, 2, 2) (9, 8, 8)
    if (threadIdx.x < GRID - cSim.NLAtomsPerWarp) {
      sEnd[threadIdx.x] = (((threadIdx.x + 9) & cSim.NLAtomsPerWarpBitsMask) +
                           8*(threadIdx.x >> cSim.NLAtomsPerWarpBits)) &
                          cSim.NLAtomsPerWarpBitsMask;
    }
    else {
      sEnd[threadIdx.x] = (((threadIdx.x + 8) & cSim.NLAtomsPerWarpBitsMask) +
                           8*(threadIdx.x >> cSim.NLAtomsPerWarpBits)) &
                           cSim.NLAtomsPerWarpBitsMask;
    }
#elif (IPS_ATOMS_PER_WARP == 8)
    // SIZE DEPENDENT 2, 8
    sStart[threadIdx.x] = (threadIdx.x + 1 + 2*(threadIdx.x >> cSim.NLAtomsPerWarpBits)) &
                          cSim.NLAtomsPerWarpBitsMask;
    // SIZE DEPENDENT (3, 2, 2) (9, 8, 8)
    if (threadIdx.x < GRID - cSim.NLAtomsPerWarp) {
      sEnd[threadIdx.x] = (((threadIdx.x + 3) & cSim.NLAtomsPerWarpBitsMask) +
                           2*(threadIdx.x >> cSim.NLAtomsPerWarpBits)) &
                          cSim.NLAtomsPerWarpBitsMask;
    }
    else {
      sEnd[threadIdx.x] = (((threadIdx.x + 2) & cSim.NLAtomsPerWarpBitsMask) +
                           2*(threadIdx.x >> cSim.NLAtomsPerWarpBits)) &
                          cSim.NLAtomsPerWarpBitsMask;
    }
#endif
  }

#ifdef IPS_VIRIAL
  if (threadIdx.x < 9) {
    sUcellf[threadIdx.x] = cSim.pNTPData->ucellf[threadIdx.x];
  }
  if (threadIdx.x < THREADS_PER_BLOCK / GRID) {
    sWarpVirial[threadIdx.x].vir_11 = 0;
    sWarpVirial[threadIdx.x].vir_22 = 0;
    sWarpVirial[threadIdx.x].vir_33 = 0;
  }
#endif

#ifdef IPS_ENERGY
  PMEForce eed  = (PMEForce)0;
  PMEForce evdw = (PMEForce)0;
#endif
  unsigned int tgx = threadIdx.x & (GRID - 1);  
  volatile NLWarp* psWarp = &sWarp[threadIdx.x / GRID];
  if (tgx == 0) 
    psWarp->pos = (blockIdx.x * blockDim.x + threadIdx.x) / GRID;
  __syncthreads();

  // Step over all neighbor list entries, advancing one tile at a time
  while (psWarp->pos < sNLEntries) {
#ifdef IPS_VIRIAL
    PMEVirial vir_11 = (PMEVirial)0;
    PMEVirial vir_22 = (PMEVirial)0;
    PMEVirial vir_33 = (PMEVirial)0;
#endif

    // Read Neighbor List entry
    unsigned int tbx = threadIdx.x - tgx;
    volatile NLForce* psF = &sForce[tbx];
    if (tgx < 4) {
      psWarp->nlEntry.array[tgx] = cSim.pNLEntry[psWarp->pos].array[tgx];
    }
    if (tgx == 0) {
      psWarp->bHomeCell = psWarp->nlEntry.NL.ymax & 0x1;
      psWarp->nlEntry.NL.ymax >>= NLENTRY_YMAX_SHIFT;
    }
    __SYNCWARP(0xFFFFFFFF);

    // Read y atoms into registers
    PMEFloat xi;
    PMEFloat yi;
    PMEFloat zi;
    PMEFloat qi;
    unsigned int LJIDi;
    unsigned int exclusion;
    PMEForce fx_i = (PMEForce)0;
    PMEForce fy_i = (PMEForce)0;
    PMEForce fz_i = (PMEForce)0;
    unsigned int index = psWarp->nlEntry.NL.ypos + (tgx & cSim.NLAtomsPerWarpBitsMask);
    if (index < psWarp->nlEntry.NL.ymax) {
      PMEFloat2 xy    = cSim.pAtomXYSP[index];
      PMEFloat2 qljid = cSim.pAtomChargeSPLJID[index];
      zi    = cSim.pAtomZSP[index];
      xi    = xy.x;
      yi    = xy.y;
      qi    = qljid.x;
#ifdef use_DPFP
      LJIDi = __double_as_longlong(qljid.y);
#else
      LJIDi = __float_as_uint(qljid.y);
#endif
    }
    else {
      xi    = (PMEFloat)10000.0 * index;
      yi    = (PMEFloat)10000.0 * index;
      zi    = (PMEFloat)10000.0 * index;
      qi    = (PMEFloat)0.0;
      LJIDi = 0;
    }

#ifndef IPS_IS_ORTHOGONAL
    // Transform into cartesian space
#ifdef IPS_VIRIAL
    xi = xi*sUcellf[0] + yi*sUcellf[1] + zi*sUcellf[2];
    yi =                 yi*sUcellf[4] + zi*sUcellf[5];
    zi =                                 zi*sUcellf[8];
#else
    xi = xi*cSim.ucellf[0][0] + yi*cSim.ucellf[0][1] + zi*cSim.ucellf[0][2];
    yi =                        yi*cSim.ucellf[1][1] + zi*cSim.ucellf[1][2];
    zi =                                               zi*cSim.ucellf[2][2];
#endif
#endif
    // Special-case first tile
    // Copy register data into shared memory
    if (psWarp->bHomeCell) {
      exclusion = cSim.pNLAtomList[psWarp->nlEntry.NL.offset +
                                   (tgx & cSim.NLAtomsPerWarpBitsMask)];
      __SYNCWARP(0xFFFFFFFF);
      if (tgx == 0) 
        psWarp->nlEntry.NL.offset += cSim.NLAtomsPerWarp;
      __SYNCWARP(0xFFFFFFFF);
#if (IPS_ATOMS_PER_WARP == 16)
      // SIZE DEPENDENT 2, 8
      exclusion >>= 8 * (tgx >> cSim.NLAtomsPerWarpBits);
#elif (IPS_ATOMS_PER_WARP == 8)
      exclusion >>= 2 * (tgx >> cSim.NLAtomsPerWarpBits);
#endif
      PSATOMX(tgx)     = xi;
      PSATOMY(tgx)     = yi;
      PSATOMZ(tgx)     = zi;
      PSATOMQ(tgx)     = qi;
      PSATOMLJID(tgx)  = LJIDi;
      LJIDi           *= cSim.LJTypes;

      // Set up iteration counts
#if (IPS_ATOMS_PER_WARP == 32)
      unsigned int j = sNext[tgx];
      unsigned int shIdx = j;
      shAtom.x    = __SHFL(0xFFFFFFFF, shAtom.x, j);
      shAtom.y    = __SHFL(0xFFFFFFFF, shAtom.y, j);
      shAtom.z    = __SHFL(0xFFFFFFFF, shAtom.z, j);
      shAtom.q    = __SHFL(0xFFFFFFFF, shAtom.q, j);
      shAtom.LJID = __SHFL(0xFFFFFFFF, shAtom.LJID, j);
      unsigned int mask1 = __BALLOT(0xFFFFFFFF, j != tgx);
      while (j != tgx) {
#else
      unsigned int j   = sStart[tgx];
      unsigned int end = sEnd[tgx];
      unsigned int shIdx = sNext[tgx];
      shAtom.x    = __SHFL(0xFFFFFFFF, shAtom.x, j);
      shAtom.y    = __SHFL(0xFFFFFFFF, shAtom.y, j);
      shAtom.z    = __SHFL(0xFFFFFFFF, shAtom.z, j);
      shAtom.q    = __SHFL(0xFFFFFFFF, shAtom.q, j);
      shAtom.LJID = __SHFL(0xFFFFFFFF, shAtom.LJID, j);
      unsigned int mask1 = __BALLOT(0xFFFFFFFF, j != end);
      while (j != end) {
#endif
        PMEFloat xij = xi - PSATOMX(j);
        PMEFloat yij = yi - PSATOMY(j);
        PMEFloat zij = zi - PSATOMZ(j);
        PMEFloat r2  = xij * xij + yij * yij + zij * zij;
        if (r2 < cSim.cut2) {
          PMEFloat rinv      = rsqrt(r2);
          PMEFloat r2inv     = rinv * rinv;
          unsigned int LJIDj = PSATOMLJID(j);
          unsigned int index = LJIDi + LJIDj;
#ifndef use_DPFP
          PMEFloat2 term = tex1Dfetch<float2>(cSim.texLJTerm, index);
#else
          PMEFloat2 term = cSim.pLJTerm[index];
#endif
          PMEFloat b0     = qi * PSATOMQ(j);
          PMEFloat r4     = r2 * r2;
          PMEFloat r6inv  = r2inv * r2inv * r2inv;
          PMEFloat r12inv = r6inv * r6inv;
          PMEFloat f6     = term.y;
          PMEFloat f12    = term.x;
          PMEFloat dpipse = -r2 * (cSim.bipse1 + r2*(cSim.bipse2 + r2*cSim.bipse3));
          PMEFloat dvcu   = -r2 * (cSim.bipsvc1 + r2*(cSim.bipsvc2 + r2*cSim.bipsvc3));
          PMEFloat dvau   = -r4 * (cSim.bipsva1 + r4*(cSim.bipsva2 + r4*cSim.bipsva3));
#ifdef IPS_ENERGY
          PMEFloat pipse  = cSim.aipse0 + r2*(cSim.aipse1 +
                                              r2*(cSim.aipse2 + r2*cSim.aipse3)) - cSim.pipsec;
          PMEFloat pvc    = cSim.aipsvc0 +
                            r2*(cSim.aipsvc1 + r2*(cSim.aipsvc2 + r2*cSim.aipsvc3)) -
                            cSim.pipsvcc;
          PMEFloat pva    = cSim.aipsva0 +
                            r4*(cSim.aipsva1 + r4*(cSim.aipsva2 + r4*cSim.aipsva3)) -
                            cSim.pipsvac;
#endif
          if (!(exclusion & 0x1)) {
            dpipse += rinv;
            dvcu   += (PMEFloat)6.0  * r6inv;
            dvau   += (PMEFloat)12.0 * r12inv;
#ifdef IPS_ENERGY
            pipse += rinv;
            pvc   += r6inv;
            pva   += r12inv;
#endif
          }
#ifdef IPS_ENERGY
#  ifndef use_DPFP
          evdw += fast_llrintf((PMEFloat)0.5 * ENERGYSCALEF * (f12 * pva - f6 * pvc));
          eed  += fast_llrintf((PMEFloat)0.5 * ENERGYSCALEF * b0 * pipse);
#  else
          evdw += (PMEFloat)0.5 * (f12 * pva - f6 * pvc);
          eed  += (PMEFloat)0.5 * b0 * pipse;
#  endif
#endif
          PMEFloat df = (f12 * dvau - f6 * dvcu + b0 * dpipse) * r2inv;
#ifndef use_DPFP
#  ifdef IPS_MINIMIZATION
          df = max(-10000.0f, min(df, 10000.0f));
#  endif
          df *= FORCESCALEF;
#  endif
          PMEFloat dfdx = df * xij;
          PMEFloat dfdy = df * yij;
          PMEFloat dfdz = df * zij;

          // Accumulate into registers only
#ifndef use_DPFP
          fx_i += fast_llrintf(dfdx);
          fy_i += fast_llrintf(dfdy);
          fz_i += fast_llrintf(dfdz);
#  ifdef IPS_VIRIAL
          vir_11 -= fast_llrintf((PMEFloat)0.5 * xij * dfdx);
          vir_22 -= fast_llrintf((PMEFloat)0.5 * yij * dfdy);
          vir_33 -= fast_llrintf((PMEFloat)0.5 * zij * dfdz);
#  endif
#else
          fx_i += (PMEForce)dfdx;
          fy_i += (PMEForce)dfdy;
          fz_i += (PMEForce)dfdz;
#  ifdef IPS_VIRIAL
          vir_11 -= (PMEVirial)((PMEFloat)0.5 * xij * dfdx);
          vir_22 -= (PMEVirial)((PMEFloat)0.5 * yij * dfdy);
          vir_33 -= (PMEVirial)((PMEFloat)0.5 * zij * dfdz);
#  endif
#endif
        }

        // Shift the exclusion counter for the next atom
        exclusion >>= 1;
        shAtom.x    = __SHFL(mask1, shAtom.x, shIdx);
        shAtom.y    = __SHFL(mask1, shAtom.y, shIdx);
        shAtom.z    = __SHFL(mask1, shAtom.z, shIdx);
        shAtom.q    = __SHFL(mask1, shAtom.q, shIdx);
        shAtom.LJID = __SHFL(mask1, shAtom.LJID, shIdx);
        j = sNext[j];
#if (IPS_ATOMS_PER_WARP == 32)
        mask1 = __BALLOT(mask1, j != tgx);
      }
#else
        mask1 = __BALLOT(mask1, j != end);
      }
#endif
      // Here ends the while loop incrementing j, bounded
      // according to the number of IPS atoms per warp.
    }
    else {
      LJIDi *= cSim.LJTypes;
    }
    // End of branch for whether the atoms in question are part of the home cell

    // Handle remainder of line
    int tx = 0;
    while (tx < psWarp->nlEntry.NL.xatoms) {

      // Read atom ID and exclusion data
      PSATOMID(tgx) = cSim.pNLAtomList[psWarp->nlEntry.NL.offset + tgx];
      __SYNCWARP(0xFFFFFFFF);
      if (tgx == 0) 
        psWarp->nlEntry.NL.offset += GRID;
      __SYNCWARP(0xFFFFFFFF);
      exclusion = cSim.pNLAtomList[psWarp->nlEntry.NL.offset +
                                   (tgx & cSim.NLAtomsPerWarpBitsMask)];
      __SYNCWARP(0xFFFFFFFF);
      if (tgx == 0) 
        psWarp->nlEntry.NL.offset += cSim.NLAtomsPerWarp;
      __SYNCWARP(0xFFFFFFFF);
#if (IPS_ATOMS_PER_WARP < 32)
      exclusion >>= cSim.NLAtomsPerWarp * (tgx >> cSim.NLAtomsPerWarpBits);
#endif

      // Clear shared memory forces
      psF[tgx].x = (PMEForce)0;
      psF[tgx].y = (PMEForce)0;
      psF[tgx].z = (PMEForce)0;

      // Read shared memory data
      if (tx + tgx < psWarp->nlEntry.NL.xatoms) {
        unsigned int atom = PSATOMID(tgx) >> NLATOM_CELL_SHIFT;
#ifndef use_DPFP
        PMEFloat2 xy    = tex1Dfetch<float2>(cSim.texAtomXYSP, atom);
        PMEFloat2 qljid = tex1Dfetch<float2>(cSim.texAtomChargeSPLJID, atom);
        PSATOMZ(tgx)    = tex1Dfetch<float>(cSim.texAtomZSP, atom);
#else
        PMEFloat2 xy    = cSim.pAtomXYSP[atom];
        PMEFloat2 qljid = cSim.pAtomChargeSPLJID[atom];
        PSATOMZ(tgx)    = cSim.pAtomZSP[atom];
#endif
        PSATOMX(tgx)    = xy.x;
        PSATOMY(tgx)    = xy.y;
        PSATOMQ(tgx)    = qljid.x;
#ifdef use_DPFP
        PSATOMLJID(tgx) = __double_as_longlong(qljid.y);
#else
        PSATOMLJID(tgx) = __float_as_uint(qljid.y);
#endif
      }
      else {
        PSATOMX(tgx)    = (PMEFloat)-10000.0 * tgx;
        PSATOMY(tgx)    = (PMEFloat)-10000.0 * tgx;
        PSATOMZ(tgx)    = (PMEFloat)-10000.0 * tgx;
        PSATOMQ(tgx)    = (PMEFloat)0.0;
        PSATOMLJID(tgx) = 0;
      }

      // Translate all atoms into a local coordinate system within one unit
      // cell of the first atom read to avoid PBC handling within inner loops
      int cell = PSATOMID(tgx) & NLATOM_CELL_TYPE_MASK;
#if defined(IPS_VIRIAL) && defined(IPS_IS_ORTHOGONAL)
      PSATOMX(tgx) += sUcellf[0] * cSim.cellOffset[cell][0];
      PSATOMY(tgx) += sUcellf[4] * cSim.cellOffset[cell][1];
      PSATOMZ(tgx) += sUcellf[8] * cSim.cellOffset[cell][2];
#else
      PSATOMX(tgx) += cSim.cellOffset[cell][0];
      PSATOMY(tgx) += cSim.cellOffset[cell][1];
      PSATOMZ(tgx) += cSim.cellOffset[cell][2];
#endif

#ifndef IPS_IS_ORTHOGONAL
#  ifdef IPS_VIRIAL
      PSATOMX(tgx) = sUcellf[0]*PSATOMX(tgx) + sUcellf[1]*PSATOMY(tgx) +
                     sUcellf[2]*PSATOMZ(tgx);
      PSATOMY(tgx) = sUcellf[4]*PSATOMY(tgx) + sUcellf[5]*PSATOMZ(tgx);
      PSATOMZ(tgx) = sUcellf[8]*PSATOMZ(tgx);
#  else
      PSATOMX(tgx) = cSim.ucellf[0][0]*PSATOMX(tgx) + cSim.ucellf[0][1]*PSATOMY(tgx) +
                     cSim.ucellf[0][2]*PSATOMZ(tgx);
      PSATOMY(tgx) = cSim.ucellf[1][1]*PSATOMY(tgx) + cSim.ucellf[1][2]*PSATOMZ(tgx);
      PSATOMZ(tgx) = cSim.ucellf[2][2]*PSATOMZ(tgx);
#  endif
#endif
      int j = tgx;
      int shIdx = sNext[tgx];

      // Branch the inner loop based on whether exclusions are present
      // to avoid having to check each interaction unnecessarily.
      if (__ANY(0xFFFFFFFF, exclusion)) {
        unsigned int mask1 = 0xFFFFFFFF;
#pragma unroll 2        
        do {
          PMEFloat xij = xi - PSATOMX(j);
          PMEFloat yij = yi - PSATOMY(j);
          PMEFloat zij = zi - PSATOMZ(j);
          PMEFloat r2  = xij*xij + yij*yij + zij*zij;
          if (r2 < cSim.cut2) {
            PMEFloat rinv      = rsqrt(r2);
            PMEFloat r2inv     = rinv * rinv;
            unsigned int LJIDj = PSATOMLJID(j);
            unsigned int index = LJIDi + LJIDj;
#ifndef use_DPFP
            PMEFloat2 term = tex1Dfetch<float2>(cSim.texLJTerm, index);
#else
            PMEFloat2 term = cSim.pLJTerm[index];
#endif
            PMEFloat f6     = term.y;
            PMEFloat f12    = term.x;
            PMEFloat b0     = qi * PSATOMQ(j);
            PMEFloat r4     = r2 * r2;
            PMEFloat r6inv  = r2inv * r2inv * r2inv;
            PMEFloat r12inv = r6inv * r6inv;
            PMEFloat dpipse = -r2 * (cSim.bipse1 + r2*(cSim.bipse2 + r2*cSim.bipse3));
            PMEFloat dvcu   = -r2 * (cSim.bipsvc1 + r2*(cSim.bipsvc2 + r2*cSim.bipsvc3));
            PMEFloat dvau   = -r4 * (cSim.bipsva1 + r4*(cSim.bipsva2 + r4*cSim.bipsva3));
#ifdef IPS_ENERGY
            PMEFloat pipse  = cSim.aipse0 +
                              r2*(cSim.aipse1 + r2*(cSim.aipse2 + r2*cSim.aipse3)) -
                              cSim.pipsec;
            PMEFloat pvc    = cSim.aipsvc0 +
                              r2*(cSim.aipsvc1 + r2*(cSim.aipsvc2 + r2*cSim.aipsvc3)) -
                              cSim.pipsvcc;
            PMEFloat pva    = cSim.aipsva0 +
                              r4*(cSim.aipsva1 + r4*(cSim.aipsva2 + r4*cSim.aipsva3)) -
                              cSim.pipsvac;
#endif
            if (!(exclusion & 0x1)) {
              dpipse += rinv;
              dvcu   += (PMEFloat)6.0  * r6inv;
              dvau   += (PMEFloat)12.0 * r12inv;
#ifdef IPS_ENERGY
              pipse += rinv;
              pvc   += r6inv;
              pva   += r12inv;
#endif
            }
#ifdef IPS_ENERGY
#  ifndef use_DPFP
            evdw += fast_llrintf(ENERGYSCALEF * (f12 * pva - f6 * pvc));
            eed  += fast_llrintf(ENERGYSCALEF * b0 * pipse);
#  else
            evdw += f12 * pva - f6 * pvc;
            eed  += b0 * pipse;
#  endif
#endif
            PMEFloat df = (f12*dvau - f6*dvcu + b0*dpipse) * r2inv;
#ifndef use_DPFP
#  ifdef IPS_MINIMIZATION
            df = max(-10000.0f, min(df, 10000.0f));
#  endif
            df *= FORCESCALEF;
#endif
            PMEFloat dfdx = df * xij;
            PMEFloat dfdy = df * yij;
            PMEFloat dfdz = df * zij;
#ifndef use_DPFP
            long long int dfdx1 = fast_llrintf(dfdx);
            long long int dfdy1 = fast_llrintf(dfdy);
            long long int dfdz1 = fast_llrintf(dfdz);
            fx_i += dfdx1;
            fy_i += dfdy1;
            fz_i += dfdz1;
            psF[j].x -= dfdx1;
            psF[j].y -= dfdy1;
            psF[j].z -= dfdz1;
#  ifdef IPS_VIRIAL
            vir_11 -= fast_llrintf(xij * dfdx);
            vir_22 -= fast_llrintf(yij * dfdy);
            vir_33 -= fast_llrintf(zij * dfdz);
#  endif
#else
            PMEForce dfdx1 = (PMEForce)dfdx;
            PMEForce dfdy1 = (PMEForce)dfdy;
            PMEForce dfdz1 = (PMEForce)dfdz;
            fx_i += dfdx1;
            fy_i += dfdy1;
            fz_i += dfdz1;
            psF[j].x -= dfdx1;
            psF[j].y -= dfdy1;
            psF[j].z -= dfdz1;
#  ifdef IPS_VIRIAL
            vir_11 -= (PMEForce)(xij * dfdx);
            vir_22 -= (PMEForce)(yij * dfdy);
            vir_33 -= (PMEForce)(zij * dfdz);
#  endif
#endif
          }

          // Shift the exclusion counter to prepare for the next atom
          exclusion >>= 1;
          shAtom.x    = __SHFL(mask1, shAtom.x, shIdx);
          shAtom.y    = __SHFL(mask1, shAtom.y, shIdx);
          shAtom.z    = __SHFL(mask1, shAtom.z, shIdx);
          shAtom.q    = __SHFL(mask1, shAtom.q, shIdx);
          shAtom.LJID = __SHFL(mask1, shAtom.LJID, shIdx);
          j = sNext[j];
          mask1 = __BALLOT(mask1, j != tgx);
        } while (j != tgx);
        // Here ends the inner loop for the case that exclusions ARE present.
      }
      else {
        unsigned int mask1 = 0xFFFFFFFF;
        do {
          PMEFloat xij = xi - PSATOMX(j);
          PMEFloat yij = yi - PSATOMY(j);
          PMEFloat zij = zi - PSATOMZ(j);
          PMEFloat r2  = xij*xij + yij*yij + zij*zij;
          if (r2 < cSim.cut2) {
            PMEFloat rinv  = rsqrt(r2);
            PMEFloat r2inv = rinv * rinv;
            unsigned int LJIDj = PSATOMLJID(j);
            unsigned int index = LJIDi + LJIDj;
#ifndef use_DPFP
            PMEFloat2 term = tex1Dfetch<float2>(cSim.texLJTerm, index);
#else
            PMEFloat2 term = cSim.pLJTerm[index];
#endif
            PMEFloat f6     = term.y;
            PMEFloat f12    = term.x;
            PMEFloat b0     = qi * PSATOMQ(j);
            PMEFloat r4     = r2 * r2;
            PMEFloat r6inv  = r2inv * r2inv * r2inv;
            PMEFloat r12inv = r6inv * r6inv;
            PMEFloat dpipse = rinv - r2*(cSim.bipse1 + r2*(cSim.bipse2 + r2*cSim.bipse3));
            PMEFloat dvcu = (PMEFloat)6.0 * r6inv -
                            r2*(cSim.bipsvc1 + r2*(cSim.bipsvc2 + r2 * cSim.bipsvc3));
            PMEFloat dvau = (PMEFloat)12.0 * r12inv -
                            r4*(cSim.bipsva1 + r4*(cSim.bipsva2 + r4*cSim.bipsva3));
            PMEFloat df = (f12*dvau - f6*dvcu + b0*dpipse) * r2inv;
#ifdef IPS_ENERGY
            PMEFloat pipse = rinv + cSim.aipse0 +
                             r2*(cSim.aipse1 + r2*(cSim.aipse2 + r2*cSim.aipse3)) -
                             cSim.pipsec;
            PMEFloat pvc   = r6inv + cSim.aipsvc0 +
                             r2*(cSim.aipsvc1 + r2*(cSim.aipsvc2 + r2*cSim.aipsvc3)) -
                             cSim.pipsvcc;
            PMEFloat pva   = r12inv + cSim.aipsva0 +
                             r4*(cSim.aipsva1 + r4*(cSim.aipsva2 + r4 * cSim.aipsva3)) -
                             cSim.pipsvac;
#  ifndef use_DPFP
            evdw += fast_llrintf(ENERGYSCALEF * (f12 * pva - f6 * pvc));
            eed  += fast_llrintf(ENERGYSCALEF * b0 * pipse);
#  else  // use_DPFP
            evdw += f12 * pva - f6 * pvc;
            eed  += b0 * pipse;
#  endif // use_DPFP
#endif
#ifndef use_DPFP
#  ifdef IPS_MINIMIZATION
            df = max(-10000.0f, min(df, 10000.0f));
#  endif
            df *= FORCESCALEF;
#endif
            PMEFloat dfdx = df * xij;
            PMEFloat dfdy = df * yij;
            PMEFloat dfdz = df * zij;
#ifndef use_DPFP
            long long int dfdx1 = fast_llrintf(dfdx);
            long long int dfdy1 = fast_llrintf(dfdy);
            long long int dfdz1 = fast_llrintf(dfdz);
            fx_i += dfdx1;
            fy_i += dfdy1;
            fz_i += dfdz1;
            psF[j].x -= dfdx1;
            psF[j].y -= dfdy1;
            psF[j].z -= dfdz1;
#  ifdef IPS_VIRIAL
            vir_11 -= fast_llrintf(xij * dfdx);
            vir_22 -= fast_llrintf(yij * dfdy);
            vir_33 -= fast_llrintf(zij * dfdz);
#  endif
#else
            PMEForce dfdx1 = (PMEForce)dfdx;
            PMEForce dfdy1 = (PMEForce)dfdy;
            PMEForce dfdz1 = (PMEForce)dfdz;
            fx_i += dfdx1;
            fy_i += dfdy1;
            fz_i += dfdz1;
            psF[j].x -= dfdx1;
            psF[j].y -= dfdy1;
            psF[j].z -= dfdz1;
#  ifdef IPS_VIRIAL
            vir_11 -= (PMEForce)(xij * dfdx);
            vir_22 -= (PMEForce)(yij * dfdy);
            vir_33 -= (PMEForce)(zij * dfdz);
#  endif
#endif
          }
          shAtom.x    = __SHFL(mask1, shAtom.x, shIdx);
          shAtom.y    = __SHFL(mask1, shAtom.y, shIdx);
          shAtom.z    = __SHFL(mask1, shAtom.z, shIdx);
          shAtom.q    = __SHFL(mask1, shAtom.q, shIdx);
          shAtom.LJID = __SHFL(mask1, shAtom.LJID, shIdx);
          j = sNext[j];
          mask1 = __BALLOT(mask1, j != tgx);
        } while (j != tgx);
        // Here ends the inner loop for the case that no exclusions will be encountered.
      }
      // End of branch for the innter loop based on the presence of non-bonded exclusions

      // Dump shared memory forces
      if (tx + tgx < psWarp->nlEntry.NL.xatoms) {
        int offset = (PSATOMID(tgx) >> NLATOM_CELL_SHIFT);
#ifndef use_DPFP
        atomicAdd((unsigned long long int*)&cSim.pNBForceXAccumulator[offset],
                  llitoulli(psF[tgx].x));
        atomicAdd((unsigned long long int*)&cSim.pNBForceYAccumulator[offset],
                  llitoulli(psF[tgx].y));
        atomicAdd((unsigned long long int*)&cSim.pNBForceZAccumulator[offset],
                  llitoulli(psF[tgx].z));
#else
#  ifdef PME_MINIMIZATION
        psF[tgx].x = max((PMEFloat)-10000.0, min(psF[tgx].x, (PMEFloat)10000.0));
        psF[tgx].y = max((PMEFloat)-10000.0, min(psF[tgx].y, (PMEFloat)10000.0));
        psF[tgx].z = max((PMEFloat)-10000.0, min(psF[tgx].z, (PMEFloat)10000.0));
#  endif
        atomicAdd((unsigned long long int*)&cSim.pNBForceXAccumulator[offset],
                  llitoulli(llrint(psF[tgx].x * FORCESCALE)));
        atomicAdd((unsigned long long int*)&cSim.pNBForceYAccumulator[offset],
                  llitoulli(llrint(psF[tgx].y * FORCESCALE)));
        atomicAdd((unsigned long long int*)&cSim.pNBForceZAccumulator[offset],
                  llitoulli(llrint(psF[tgx].z * FORCESCALE)));
#endif
      }

      // Advance to next x tile
      tx += GRID;
    }

    // Reduce register forces if necessary
#if (IPS_ATOMS_PER_WARP <= 16)
    psF[tgx].x = fx_i;
    psF[tgx].y = fy_i;
    psF[tgx].z = fz_i;
#  if (IPS_ATOMS_PER_WARP == 16)
    if (tgx < 16) {
      fx_i += psF[tgx + 16].x;
      fy_i += psF[tgx + 16].y;
      fz_i += psF[tgx + 16].z;
    }
#  elif (IPS_ATOMS_PER_WARP == 8)
    if (tgx < 8) {
      fx_i += psF[tgx + 8].x + psF[tgx + 16].x + psF[tgx + 24].x;
      fy_i += psF[tgx + 8].y + psF[tgx + 16].y + psF[tgx + 24].y;
      fz_i += psF[tgx + 8].z + psF[tgx + 16].z + psF[tgx + 24].z;
    }
#  endif
#endif

    // Dump register forces
    if (psWarp->nlEntry.NL.ypos + tgx < psWarp->nlEntry.NL.ymax) {
      int offset = psWarp->nlEntry.NL.ypos + tgx;
#ifndef use_DPFP
      atomicAdd((unsigned long long int*)&cSim.pNBForceXAccumulator[offset], llitoulli(fx_i));
      atomicAdd((unsigned long long int*)&cSim.pNBForceYAccumulator[offset], llitoulli(fy_i));
      atomicAdd((unsigned long long int*)&cSim.pNBForceZAccumulator[offset], llitoulli(fz_i));
#else
#ifdef PME_MINIMIZATION
      fx_i = max((PMEFloat)-10000.0, min(fx_i, (PMEFloat)10000.0));
      fy_i = max((PMEFloat)-10000.0, min(fy_i, (PMEFloat)10000.0));
      fz_i = max((PMEFloat)-10000.0, min(fz_i, (PMEFloat)10000.0));
#endif
      atomicAdd((unsigned long long int*)&cSim.pNBForceXAccumulator[offset],
                llitoulli(llrint(fx_i * FORCESCALE)));
      atomicAdd((unsigned long long int*)&cSim.pNBForceYAccumulator[offset],
                llitoulli(llrint(fy_i * FORCESCALE)));
      atomicAdd((unsigned long long int*)&cSim.pNBForceZAccumulator[offset],
                llitoulli(llrint(fz_i * FORCESCALE)));
#endif
    }

#ifdef IPS_VIRIAL
    // Reduce virial per warp and convert to fixed point if necessary
    volatile NLVirial* psV = &sWarpVirial[threadIdx.x / GRID];
    psF[tgx].x  = vir_11;
    psF[tgx].y  = vir_22;
    psF[tgx].z  = vir_33;
    psF[tgx].x += psF[tgx ^ 1].x;
    psF[tgx].y += psF[tgx ^ 1].y;
    psF[tgx].z += psF[tgx ^ 1].z;
    psF[tgx].x += psF[tgx ^ 2].x;
    psF[tgx].y += psF[tgx ^ 2].y;
    psF[tgx].z += psF[tgx ^ 2].z;
    psF[tgx].x += psF[tgx ^ 4].x;
    psF[tgx].y += psF[tgx ^ 4].y;
    psF[tgx].z += psF[tgx ^ 4].z;
    psF[tgx].x += psF[tgx ^ 8].x;
    psF[tgx].y += psF[tgx ^ 8].y;
    psF[tgx].z += psF[tgx ^ 8].z;
    psF[tgx].x += psF[tgx ^ 16].x;
    psF[tgx].y += psF[tgx ^ 16].y;
    psF[tgx].z += psF[tgx ^ 16].z;
    if (tgx == 0) {
#ifndef use_DPFP
      psV->vir_11 += psF[tgx].x;
      psV->vir_22 += psF[tgx].y;
      psV->vir_33 += psF[tgx].z;
#else
      psV->vir_11 += llrint(psF[tgx].x * FORCESCALE);
      psV->vir_22 += llrint(psF[tgx].y * FORCESCALE);
      psV->vir_33 += llrint(psF[tgx].z * FORCESCALE);
#endif
    }
#endif
    // Get next Neighbor List entry
    if (tgx == 0) {
      psWarp->pos = atomicAdd(&cSim.pFrcBlkCounters[0], 1);
    }
    __SYNCWARP(0xFFFFFFFF);
  }

#ifdef IPS_VIRIAL
  volatile NLVirial* psV = &sWarpVirial[threadIdx.x / GRID];
  if ((threadIdx.x & GRID_BITS_MASK) == 0) {
    unsigned long long int val1 = llitoulli(psV->vir_11);
    unsigned long long int val2 = llitoulli(psV->vir_22);
    unsigned long long int val3 = llitoulli(psV->vir_33);
    atomicAdd(cSim.pVirial_11, val1);
    atomicAdd(cSim.pVirial_22, val2);
    atomicAdd(cSim.pVirial_33, val3);
  }
#endif

#ifdef IPS_ENERGY
#define sEED(i)  sForce[i].x
#define sEVDW(i) sForce[i].y
  sEED(threadIdx.x)   = eed;
  sEVDW(threadIdx.x)  = evdw;
  sEED(threadIdx.x)  +=  sEED(threadIdx.x ^ 1);
  sEVDW(threadIdx.x) += sEVDW(threadIdx.x ^ 1);
  sEED(threadIdx.x)  +=  sEED(threadIdx.x ^ 2);
  sEVDW(threadIdx.x) += sEVDW(threadIdx.x ^ 2);
  sEED(threadIdx.x)  +=  sEED(threadIdx.x ^ 4);
  sEVDW(threadIdx.x) += sEVDW(threadIdx.x ^ 4);
  sEED(threadIdx.x)  +=  sEED(threadIdx.x ^ 8);
  sEVDW(threadIdx.x) += sEVDW(threadIdx.x ^ 8);
  sEED(threadIdx.x)  +=  sEED(threadIdx.x ^ 16);
  sEVDW(threadIdx.x) += sEVDW(threadIdx.x ^ 16);
  if ((threadIdx.x & GRID_BITS_MASK) == 0) {
#ifndef use_DPFP
    atomicAdd(cSim.pEED, llitoulli(sEED(threadIdx.x)));
    atomicAdd(cSim.pEVDW, llitoulli(sEVDW(threadIdx.x)));
#else  // use_DPFP
    atomicAdd(cSim.pEED, llitoulli(llrint(ENERGYSCALE * sEED(threadIdx.x))));
    atomicAdd(cSim.pEVDW, llitoulli(llrint(ENERGYSCALE * sEVDW(threadIdx.x))));
#endif
  }
#undef sEED
#undef sEVDW
#endif
#undef PSATOMX
#undef PSATOMY
#undef PSATOMZ
#undef PSATOMQ
#undef PSATOMLJID
#undef PSATOMID
}

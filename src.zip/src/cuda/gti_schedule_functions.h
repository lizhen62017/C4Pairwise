
#ifndef __GTI_SCHEDULE_H__
#define __GTI_SCHEDULE_H__
#ifdef GTI

#include "gti_const.cuh"



template <typename T> __TARGET T smooth_tanh_func(T  x, T x0, T scale, unsigned direction) {
  T ss = HalfF * Tanh((x - x0) / scale);
  return (direction == 0) ? HalfF + ss : HalfF - ss;
}

template <typename T> __TARGET T d_smooth_tanh_func(T  x, T x0, T scale, unsigned direction) {
  T ss = Tanh((x - x0) / scale);
  T tt = HalfF * (OneF - ss * ss) / scale;
  return (direction == 0) ? tt : -tt;
}

template <typename T> __TARGET T smooth_step1_func(T  x) {
  return (x * x * (3 -2 * x ));
}
template <typename T> __TARGET T d_smooth_step1_func(T  x) {
  return x* (6 - 6 * x);
}

template <typename T> __TARGET T smooth_step2_func(T  x) {
  return (x * x * x * (10 - 15 * x + 6 * x * x));
}
template <typename T> __TARGET T d_smooth_step2_func(T  x) {
  return (x * x * (30 - 60 * x + 30 * x * x));
}

template <typename T> __TARGET T smooth_step3_func(T  x) {
  return (x * x * x * x * (35 - 84 * x + 70 * x * x - 20 * x * x *x));
}
template <typename T> __TARGET T d_smooth_step3_func(T  x) {
  return (x * x * x * (140 - 420 * x + 420 * x * x - 140 * x * x * x));
}

template <typename T> __TARGET T smooth_step4_func(T  x) {
  return (x * x * x * x * x* (126 - 420 * x + 540 * x * x - 315 * x * x * x + 70 *x*x*x*x ));
}
template <typename T> __TARGET T d_smooth_step4_func(T  x) {
  return (x * x * x * x* (126*5 - 420 *6* x + 540 *7* x * x - 315 * 8* x * x * x + 70 * 9* x * x * x * x));
}


template <typename T> __TARGET T smooth_step_func(T  x, int n) {
  switch (n) {
  case(-1): return smooth_tanh_func(x, T(0.5), T(0.15), unsigned(One));
  case(0): return  x;
  case(1): return (smooth_step1_func(x));
  case(2): return (smooth_step2_func(x));
  case(3): return (smooth_step3_func(x));
  case(4): return (smooth_step4_func(x));
  }
  
  // Return something to turn off warning
  return x;
}

template <typename T> __TARGET T d_smooth_step_func(T  x, int n) {
  switch (n) {
  case(-1): return d_smooth_tanh_func(x, T(0.5), T(0.15), unsigned(One));
  case(0): return OneF;
  case(1): return (d_smooth_step1_func(x));
  case(2): return (d_smooth_step2_func(x));
  case(3): return (d_smooth_step3_func(x));
  case(4): return (d_smooth_step4_func(x));
  }
  
  // Return something to turn off warning
  return OneF;
}
// Singleton pattern for the global instance 
class LambdaSchedule {

public:

  // This section much be consistent w/ gti.F90 and ti.F90
  enum LambdaType { TypeGen = 0, TypeBAT = 1, TypeEleRec = 2, TypeEleCC = 3, TypeEleSC = 4, TypeVDW = 5, TypeRestBA = 6, TypeTotal = 7 };

  enum FunctionType { smooth_tanh=-1, linear=0, smooth_step1=1, smooth_step2=2, smooth_step3=3, smooth_step4=4};
  enum Direction { forward, backward };
  enum Matchtype { symmetric, complementary};


  static LambdaSchedule& GetReference()
  {
    static LambdaSchedule thisInstance;
    return thisInstance;
  };

  void Init(bool useSchedule);
  void Init(char* schFileName);

  void Get_lambda_weight(int interaction, double lambda, double& weight, double& dWeight, Direction direction=forward) const;
  void Get_lambda_weight(int interaction, int sizeN, double lambdas[], double weights[], double dWeights[], Direction direction=forward) const;

  FunctionType GetFunctionType(LambdaType interaction) const;

protected:

  LambdaSchedule();
  virtual ~LambdaSchedule();

  void Setup(int interaction, FunctionType type, Matchtype match, double p0, double p1);
 
private:

  struct Interaction {
    FunctionType functionType=linear;
    Matchtype match=complementary;
    double parameter[4] = { 0.0, 1.0, 0.0, 0.0 };
  };
  Interaction m_interaction[TypeTotal];

  bool m_init = false;
};


#endif  /* GTI */
#endif  /*  __GTI_SCHEDULE_H__ */


#ifdef GTI
#include "gti_simulationConst.h"

//---------------------------------------------------------------------------------------------
// InitSimulationConst: initialize the simulation constants structure within the gpuContext
//---------------------------------------------------------------------------------------------
void gti_simulationConst::InitSimulationConst()
{
  base_simulationConst::InitSimulationConst();

  needMBAR=false;
  pNTPData = NULL;
  pTIList = NULL;
  pSCList = NULL;
  numberTIAtoms = 0;
  numberTICommonPairs = 0;
  doTIHeating = false;
}

#endif


#include "copyright.i"

//---------------------------------------------------------------------------------------------
// AMBER NVIDIA CUDA GPU IMPLEMENTATION: PMEMD VERSION
//
// July 2017, by Scott Le Grand, David S. Cerutti, Daniel J. Mermelstein, Charles Lin, and
//               Ross C. Walker
//---------------------------------------------------------------------------------------------

//---------------------------------------------------------------------------------------------
// This is included by kBWU.h with options for #define'd LOCAL_AFE and LOCAL_MBAR.  A third
// define, LOCAL_ENERGY, applies at the level of kBWU.h but cascades down into this code as
// well.  This code does not constitute an entire kernel, but rather a section of one.
//
// Variables already defined before including this code:
//   atmcrd[x,y,z]:  coordinates for imported atoms
//   atmfrc[x,y,z]:  force accumulators for imported atoms
//   nrgACC:         accumulator for energy terms
//   startidx:       starting index for this warp's set of GRID (that is, 32) bonded terms
//   tgx:            thread index within the warp
//---------------------------------------------------------------------------------------------
{
  unsigned int rawID = cSim.pBwuNB14ID[startidx + tgx];
#ifdef LOCAL_VIRIAL
  PMEAccumulator v11 = (PMEAccumulator)0;
  PMEAccumulator v22 = (PMEAccumulator)0;
  PMEAccumulator v33 = (PMEAccumulator)0;
#endif
#ifdef LOCAL_ENERGY
  // In this special case, there are two accumulators to track: the accumulator inherited from
  // kBWU.h, scEcomp, will take the role of tracking Lennard-Jones soft-core interactions
  // (nb14), while a new accumulator, scEel14comp, will handle electrostatics 1-4 soft-core
  // interactions.  Similarly, eel14 will handle the overall accumulation of electrostatic
  // energy while the inherited eterm goes to Lennard-Jones interactions.
  PMEAccumulator eel14;
#  ifdef LOCAL_AFE
  PMEAccumulator scEel14comp[2] = {(PMEAccumulator)0, (PMEAccumulator)0};
#  endif
  if (rawID == 0xffffffff) {
    eterm = (PMEAccumulator)0;
    eel14 = (PMEAccumulator)0;
  }
  else {
#else
  if (rawID != 0xffffffff) {
#endif
    unsigned int atmI = rawID >> 8;
    unsigned int atmJ = rawID & 0xff;
    PMEFloat dx = atmcrdx[atmJ] - atmcrdx[atmI];
    PMEFloat dy = atmcrdy[atmJ] - atmcrdy[atmI];
    PMEFloat dz = atmcrdz[atmJ] - atmcrdz[atmI];
    PMEFloat2 scnb  = cSim.pBwuLJnb14[startidx + tgx];
    PMEFloat qterm  = cSim.pBwuEEnb14[startidx + tgx];
    PMEFloat r2     = dx*dx + dy*dy + dz*dz;
    PMEFloat rinv   = rsqrt(r2);
    PMEFloat r2inv  = rinv * rinv;
    PMEFloat r6     = r2inv * r2inv * r2inv;
    PMEFloat g      = rinv * qterm;
    PMEFloat f6     = scnb.y * r6;
    PMEFloat f12    = scnb.x * (r6 * r6);
    PMEFloat df     = (g + (PMEFloat)12.0*f12 - (PMEFloat)6.0*f6) * r2inv;
#ifdef LOCAL_AFE
    unsigned int TIstatus = cSim.pBwuNB14Status[startidx + tgx];
    TIregion = TIstatus >> 16;
    CVterm = TIstatus & 0xff;
    PMEFloat lambda = TISetLambda(CVterm, TIregion, cSim.AFElambdaSP[1]);
    df *= lambda;
#endif
#ifdef use_DPFP
    PMEAccumulator ifx = llrint(df * dx * FORCESCALE);
    PMEAccumulator ify = llrint(df * dy * FORCESCALE);
    PMEAccumulator ifz = llrint(df * dz * FORCESCALE);
#  ifdef LOCAL_VIRIAL
    v11 -= llrint(df * dx * dx * FORCESCALE);
    v22 -= llrint(df * dy * dy * FORCESCALE);
    v33 -= llrint(df * dz * dz * FORCESCALE);
#  endif
    atomicAdd((unsigned long long int*)&atmfrcx[atmJ], llitoulli( ifx));
    atomicAdd((unsigned long long int*)&atmfrcy[atmJ], llitoulli( ify));
    atomicAdd((unsigned long long int*)&atmfrcz[atmJ], llitoulli( ifz));
    atomicAdd((unsigned long long int*)&atmfrcx[atmI], llitoulli(-ifx));
    atomicAdd((unsigned long long int*)&atmfrcy[atmI], llitoulli(-ify));
    atomicAdd((unsigned long long int*)&atmfrcz[atmI], llitoulli(-ifz));
#else  // use_DPFP
    int ifx = __float2int_rn(df * dx * BSCALEF);
    int ify = __float2int_rn(df * dy * BSCALEF);
    int ifz = __float2int_rn(df * dz * BSCALEF);
#  ifdef LOCAL_VIRIAL
    v11 -= fast_llrintf(df * dx * dx * FORCESCALEF);
    v22 -= fast_llrintf(df * dy * dy * FORCESCALEF);
    v33 -= fast_llrintf(df * dz * dz * FORCESCALEF);
#  endif
    atomicAdd(&atmfrcx[atmJ],  ifx);
    atomicAdd(&atmfrcy[atmJ],  ify);
    atomicAdd(&atmfrcz[atmJ],  ifz);
    atomicAdd(&atmfrcx[atmI], -ifx);
    atomicAdd(&atmfrcy[atmI], -ify);
    atomicAdd(&atmfrcz[atmI], -ifz);
#endif // use_DPFP
#ifdef LOCAL_ENERGY
#  ifdef LOCAL_AFE
    SCterm = (TIstatus >> 8) & 0xff;
    if (SCterm == 0) {
      eel14 = llrint(ENERGYSCALE * lambda * g);
      eterm = llrint(ENERGYSCALE * lambda * (f12 - f6));
    }
    else {
      scEel14comp[TIregion - 1] = llrint(ENERGYSCALE * g);
      scEcomp[TIregion - 1]     = llrint(ENERGYSCALE * (f12 - f6));
      eel14 = (PMEAccumulator)0;
      eterm = (PMEAccumulator)0;
    }
    edvdl = llrint((PMEDouble)(CVterm * (2*TIregion - 3)) * ENERGYSCALE * (g + (f12 - f6)));
#    ifdef LOCAL_MBAR
    // Set pieces of information that MBAR will need based on this thread's results
    mbarTerm = g + (f12 - f6);
    mbarRefLambda = lambda;
#    endif
#  else
    eel14 = llrint(ENERGYSCALE * g);
    eterm = llrint(ENERGYSCALE * (f12 - f6));
#  endif
  }
#  define NB14_CASE
#  define EACC_OFFSET   SCNB_EACC_OFFSET
#  define STORE_SCR1    cSim.pSCVDW14R1
#  define STORE_SCR2    cSim.pSCVDW14R2
#include "kBWU_EnergyReduction.h"
#  undef EACC_OFFSET
#  undef STORE_SCR1
#  undef STORE_SCR2
#  undef NB14_CASE
#else
  }
#endif // LOCAL_ENERGY
#ifdef LOCAL_VIRIAL
  v11 += __SHFL(0xFFFFFFFF, v11, tgx + 16);
  v11 += __SHFL(0xFFFFFFFF, v11, tgx +  8);
  v11 += __SHFL(0xFFFFFFFF, v11, tgx +  4);
  v11 += __SHFL(0xFFFFFFFF, v11, tgx +  2);
  v11 += __SHFL(0xFFFFFFFF, v11, tgx +  1);
  v22 += __SHFL(0xFFFFFFFF, v22, tgx + 16);
  v22 += __SHFL(0xFFFFFFFF, v22, tgx +  8);
  v22 += __SHFL(0xFFFFFFFF, v22, tgx +  4);
  v22 += __SHFL(0xFFFFFFFF, v22, tgx +  2);
  v22 += __SHFL(0xFFFFFFFF, v22, tgx +  1);
  v33 += __SHFL(0xFFFFFFFF, v33, tgx + 16);
  v33 += __SHFL(0xFFFFFFFF, v33, tgx +  8);
  v33 += __SHFL(0xFFFFFFFF, v33, tgx +  4);
  v33 += __SHFL(0xFFFFFFFF, v33, tgx +  2);
  v33 += __SHFL(0xFFFFFFFF, v33, tgx +  1);
  if (tgx == 0) {
    atomicAdd(cSim.pVirial_11, llitoulli(v11));
    atomicAdd(cSim.pVirial_22, llitoulli(v22));
    atomicAdd(cSim.pVirial_33, llitoulli(v33));
  }
#endif
}

#ifndef _BASE_XRAY_DEV_CONSTANT_FUNCS
#define _BASE_XRAY_DEV_CONSTANT_FUNCS

#include "base_xrayDevConstants.h"

void base_xrayDevConstants::InitXrayDevConstants()
{

}

#endif


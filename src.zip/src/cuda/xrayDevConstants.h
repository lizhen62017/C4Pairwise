#ifndef _XRAY_CALCULATION
#define _XRAY_CALCULATION

#  include "base_xrayDevConstants.h"
typedef base_xrayDevConstants xrayDevConstants;

#endif

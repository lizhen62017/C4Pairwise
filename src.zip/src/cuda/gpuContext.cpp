#include "gpuContext.h"

gpuContext theGPUContext::thisInstance = NULL;
bool theGPUContext::init = false;
bool theGPUContext::shutdown = false;

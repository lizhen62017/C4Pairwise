#include "copyright.i"

//---------------------------------------------------------------------------------------------
// AMBER NVIDIA CUDA GPU IMPLEMENTATION: PMEMD VERSION
//
// July 2017, by Scott Le Grand, David S. Cerutti, Daniel J. Mermelstein, Charles Lin, and
//               Ross C. Walker
//---------------------------------------------------------------------------------------------

//---------------------------------------------------------------------------------------------
// This is included by kForcesUpdate to integrate the equations of motion (move the atoms), and
// can be thought of as "k-Update.h."
//
// #defines: UPDATE_NEIGHBORLIST, UPDATE_LANGEVIN, UPDATE_RELAXMD
//---------------------------------------------------------------------------------------------
{
#ifdef UPDATE_NEIGHBORLIST
#  define MASS(i) cSim.pImageMass[i]
#  define INVMASS(i) cSim.pImageInvMass[i]
#  define VELX(i) cSim.pImageVelX[i]
#  define VELY(i) cSim.pImageVelY[i]
#  define VELZ(i) cSim.pImageVelZ[i]
#  define LVELX(i) cSim.pImageLVelX[i]
#  define LVELY(i) cSim.pImageLVelY[i]
#  define LVELZ(i) cSim.pImageLVelZ[i]
#  define ATOMX(i) cSim.pImageX[i]
#  define ATOMY(i) cSim.pImageY[i]
#  define ATOMZ(i) cSim.pImageZ[i]
#else
#  define MASS(i) cSim.pAtomMass[i]
#  define INVMASS(i) cSim.pAtomInvMass[i]
#  define VELX(i) cSim.pVelX[i]
#  define VELY(i) cSim.pVelY[i]
#  define VELZ(i) cSim.pVelZ[i]
#  define LVELX(i) cSim.pLVelX[i]
#  define LVELY(i) cSim.pLVelY[i]
#  define LVELZ(i) cSim.pLVelZ[i]
#  define ATOMX(i) cSim.pAtomX[i]
#  define ATOMY(i) cSim.pAtomY[i]
#  define ATOMZ(i) cSim.pAtomZ[i]
#endif

  double dtx       = dt * 20.455;
#ifdef UPDATE_LANGEVIN
  double gammai    = gamma_ln / 20.455;
  double half_dtx = dtx * 0.5;
  double c_implic  = 1.0 / (1.0 + gammai * half_dtx);
  double c_explic  = 1.0 - gammai * half_dtx;
  double sdfac     = 4.0 * gammai * boltz2 * temp0 / dtx;
#endif
  unsigned int pos = blockIdx.x * blockDim.x + threadIdx.x;
  if (pos < cSim.atoms) {

#ifdef UPDATE_LANGEVIN
    if (cSim.doTIHeating) {
      unsigned realAtomindex = cSim.pImageAtom[pos];
      if (cSim.pTIList[realAtomindex] > 0 || cSim.pTIList[realAtomindex + cSim.stride] > 0) {
        gammai *= 100.0;
        sdfac = 4.0 * gammai * boltz2 * cSim.TIHeatingTemp / dtx;  
      }
      else {
        gammai /= 100.0;
        sdfac = 4.0 * gammai * boltz2 * temp0 / dtx;  
      }
    }
    else {
      sdfac = 4.0 * gammai * boltz2 * temp0 / dtx;
    } 
    c_implic = 1.0 / (1.0 + gammai * half_dtx);
    c_explic = 1.0 - gammai * half_dtx;
#endif

    double atomX   = ATOMX(pos);
    double atomY   = ATOMY(pos);
    double atomZ   = ATOMZ(pos);
    double invMass = INVMASS(pos);
#ifdef UPDATE_LANGEVIN
    double aamass  = MASS(pos);
#endif
#ifdef UPDATE_RELAXMD
    unsigned int index = cSim.pImageAtom[pos];
#endif
    PMEAccumulator fx = cSim.pForceXAccumulator[pos];
    PMEAccumulator fy = cSim.pForceYAccumulator[pos];
    PMEAccumulator fz = cSim.pForceZAccumulator[pos];
#if defined(UPDATE_NTP) && !defined(MPI)
    PMEAccumulator nfx = cSim.pNBForceXAccumulator[pos];
    PMEAccumulator nfy = cSim.pNBForceYAccumulator[pos];
    PMEAccumulator nfz = cSim.pNBForceZAccumulator[pos];
    double forceX = (double)(fx + nfx) * (double)ONEOVERFORCESCALE;
    double forceY = (double)(fy + nfy) * (double)ONEOVERFORCESCALE;
    double forceZ = (double)(fz + nfz) * (double)ONEOVERFORCESCALE;
#else
    double forceX = (double)fx * (double)ONEOVERFORCESCALE;
    double forceY = (double)fy * (double)ONEOVERFORCESCALE;
    double forceZ = (double)fz * (double)ONEOVERFORCESCALE;
#endif
    double velX  = VELX(pos);
    double velY  = VELY(pos);
    double velZ  = VELZ(pos);
#ifdef UPDATE_LANGEVIN
    double gaussX = cSim.pRandomX[pos + rpos];
    double gaussY = cSim.pRandomY[pos + rpos];
    double gaussZ = cSim.pRandomZ[pos + rpos];
    double rsd    = sqrt(sdfac * aamass);
#endif
    double wfac = invMass * dtx;
    
    // Save previous velocities and positions
    LVELX(pos) = velX;
    LVELY(pos) = velY;
    LVELZ(pos) = velZ;
    cSim.pOldAtomX[pos] = atomX;
    cSim.pOldAtomY[pos] = atomY;
    cSim.pOldAtomZ[pos] = atomZ;

    // Update velocities
#ifdef UPDATE_RELAXMD
    if (index >= cSim.first_update_atom) {
#endif
#ifdef UPDATE_LANGEVIN
      velX = (velX*c_explic + (forceX + rsd*gaussX)*wfac) * c_implic;
      velY = (velY*c_explic + (forceY + rsd*gaussY)*wfac) * c_implic;
      velZ = (velZ*c_explic + (forceZ + rsd*gaussZ)*wfac) * c_implic;
#else
      velX += forceX * wfac;
      velY += forceY * wfac;
      velZ += forceZ * wfac;
#endif
      if (cSim.vlimit > 0) {
        if (isnan(velX) || isinf(velX)) {
          velX = 0.0;
        }
        velX = max(min(velX, cSim.vlimit), -cSim.vlimit);
        if (isnan(velY) || isinf(velY)) {
          velY = 0.0;
        }
        velY = max(min(velY, cSim.vlimit), -cSim.vlimit);
        if (isnan(velZ) || isinf(velZ)) {
          velZ = 0.0;
        }
        velZ = max(min(velZ, cSim.vlimit), -cSim.vlimit);
      }

      // Save new velocity
      VELX(pos)= velX;
      VELY(pos)= velY;
      VELZ(pos)= velZ;

      // Update positions for SHAKE and kinetic energy kernel
      double newAtomX = atomX + velX*dtx;
      double newAtomY = atomY + velY*dtx;
      double newAtomZ = atomZ + velZ*dtx;
      ATOMX(pos) = newAtomX;
      ATOMY(pos) = newAtomY;
      ATOMZ(pos) = newAtomZ;
#ifndef UPDATE_NEIGHBORLIST
      PMEFloat2 xy;
      xy.x = newAtomX;
      xy.y = newAtomY;
      cSim.pAtomXYSP[pos] = xy;
      cSim.pAtomZSP[pos]  = newAtomZ;
#endif
#ifdef UPDATE_RELAXMD
    }
#endif
  }
#undef MASS
#undef INVMASS
#undef VELX
#undef VELY
#undef VELZ
#undef LVELX
#undef LVELY
#undef LVELZ
#undef ATOMX
#undef ATOMY
#undef ATOMZ
}

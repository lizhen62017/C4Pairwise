#include "copyright.i"

//---------------------------------------------------------------------------------------------
// AMBER NVIDIA CUDA GPU IMPLEMENTATION: PMEMD VERSION
//
// July 2017, by Scott Le Grand, David S. Cerutti, Daniel J. Mermelstein, Charles Lin, and
//               Ross C. Walker
//---------------------------------------------------------------------------------------------

//---------------------------------------------------------------------------------------------
// This is included by kCalculatePMENonbondEnergy.cu, many times for different kernels
// calculating forces, energies, and virials, all with different numbers of atoms per warp.
// VDW force-switching code could use optimization.
//
// #defines: PME_ENERGY, PME_VIRIAL, PME_IS_ORTHOGONAL, PME_ATOMS_PER_WARP, PME_MINIMIZATION
//
// In this file, there is another added convention that nested pre-processor directives are
// also indented, as there are so many of them.
//---------------------------------------------------------------------------------------------
{
#define uint unsigned int
  struct NLAtom {
    PMEFloat x;
    PMEFloat y;
    PMEFloat z;
    PMEFloat q;
    unsigned int LJID;
    unsigned int ID;
  };

#ifndef use_SPFP
  struct NLForce {
    PMEForce x;
    PMEForce y;
    PMEForce z;
  };
#endif

  struct NLWarp {
    NLEntry nlEntry;
    uint pos;
    bool bHomeCell;
  };

  const PMEFloat delta = 1.0e-5;
#ifdef PME_ENERGY
  const PMEFloat sixth = (PMEFloat)0.16666666666667;
  const PMEFloat twelvth = (PMEFloat)0.083333333333333;
#endif
  
#if defined(PME_VIRIAL) || defined(PME_ENERGY)
  const int THREADS_PER_BLOCK = PMENONBONDENERGY_THREADS_PER_BLOCK;
#else
  const int THREADS_PER_BLOCK = PMENONBONDFORCES_THREADS_PER_BLOCK;
#endif

  __shared__ unsigned int sNLEntries;
#if defined(PME_VIRIAL)
  __shared__ PMEFloat sUcellf[9];
#endif
  __shared__ unsigned int sNext[GRID];
  __shared__ unsigned int sRecv[GRID];
#if (PME_ATOMS_PER_WARP <= 16)
  __shared__ unsigned int sStart[GRID];
  __shared__ unsigned int sRecvStart[GRID];
#endif
  __shared__ volatile NLWarp sWarp[THREADS_PER_BLOCK / GRID];

  // Read static data
  if (threadIdx.x == 0) {
    sNLEntries = *(cSim.pNLEntries);
  }
  if (threadIdx.x < GRID) {
    unsigned int offset = cSim.NLAtomsPerWarp * (threadIdx.x >> cSim.NLAtomsPerWarpBits);
    sNext[threadIdx.x] = ((threadIdx.x + 1) & cSim.NLAtomsPerWarpBitsMask) + offset;
    sRecv[threadIdx.x] = threadIdx.x - 1 +
                         cSim.NLAtomsPerWarp*((threadIdx.x &
                                               cSim.NLAtomsPerWarpBitsMask) == 0);
  }
#if (PME_ATOMS_PER_WARP == 16)
  if (threadIdx.x < GRID) {
    // Fast-forward four steps in the final 16 lanes for the first tile computation
    // (the first tile has 128-16 = 112 interactions to compute, which is 96 interactions
    // in three iterations of the 32-lane warp plus 32 more interactions each computed at
    // half strength).
    unsigned int basenum = ((threadIdx.x + 1) & 15) + 20*(threadIdx.x >= 16);
    sStart[threadIdx.x] = basenum - 16*(basenum >> 5);
    basenum = threadIdx.x + 16*((threadIdx.x & 15) == 0) + 12*(threadIdx.x >= 16) - 1;
    sRecvStart[threadIdx.x] = basenum - 16*(basenum >> 5);
  }
#elif (PME_ATOMS_PER_WARP == 8)
  __syncthreads();
  if (threadIdx.x < GRID) {
    // For 8 atoms per warp, there are only 28 interactions to compute, which is 24
    // computed at full strength and 8 more computed at half strength.  This can all
    // be done in a single execution of the 32-lane warp.
    int j = sNext[threadIdx.x];
    int jrec = sRecv[threadIdx.x];
    int ffstep = threadIdx.x >> 3;
    while (ffstep > 0) {
      j = sNext[j];
      jrec = sRecv[jrec];
      ffstep--;
    }
    sStart[threadIdx.x] = j;
    sRecvStart[threadIdx.x] = jrec;
  }
#endif // End branch for different numbers of atoms per warp

#ifdef PME_VIRIAL
  if (threadIdx.x < 9) {
    sUcellf[threadIdx.x] = cSim.pNTPData->ucellf[threadIdx.x];
  }
#endif
#ifdef PME_ENERGY
  PMEForceAccumulator eed, evdw;
  eed = (PMEForceAccumulator)0;
  evdw = (PMEForceAccumulator)0;
#  if defined(use_DPFP) && defined(PME_MINIMIZATION)
  long long int eede = 0;
  long long int evdwe = 0;  
#  endif
#endif

#ifdef PME_VIRIAL
  PMEVirialAccumulator vir_11, vir_22, vir_33;
  vir_11 = (PMEVirialAccumulator)0;
  vir_22 = (PMEVirialAccumulator)0;
  vir_33 = (PMEVirialAccumulator)0;  
#  if defined(use_DPFP) && defined(PME_MINIMIZATION)
  long long int vir_11E = 0;
  long long int vir_22E = 0;
  long long int vir_33E = 0;
#  endif 
#endif


  // Position in the warp and warp indexing into __shared__ arrays
  unsigned int tgx = threadIdx.x & (GRID - 1);
  
  volatile NLWarp* psWarp = &sWarp[threadIdx.x / GRID];
  if(tgx == 0){
    psWarp->pos = ((blockIdx.x * blockDim.x) + threadIdx.x) / GRID;
  }
  __syncthreads();

  // Massive loop over all neighbor list entries
  while (psWarp->pos < sNLEntries) {

    // Read Neighbor List entry
    if (tgx < 4) {
      psWarp->nlEntry.array[tgx] = cSim.pNLEntry[psWarp->pos].array[tgx];
    }
    __SYNCWARP(0xFFFFFFFF);
    if (tgx == 0) {
      psWarp->bHomeCell = psWarp->nlEntry.NL.ymax & 0x1;
      psWarp->nlEntry.NL.ymax >>= NLENTRY_YMAX_SHIFT;
    }
    __SYNCWARP(0xFFFFFFFF);

    // Read y atoms into registers
    PMEFloat xi;
    PMEFloat yi;
    PMEFloat zi;
    PMEFloat qi;
    unsigned int LJIDi;
    unsigned int exclusion;
    PMEForceAccumulator fx_i, fy_i, fz_i;
    fx_i = (PMEForceAccumulator)0;
    fy_i = (PMEForceAccumulator)0;
    fz_i = (PMEForceAccumulator)0;
#if defined(use_DPFP) && defined(PME_MINIMIZATION)
    long long int fxe_i = 0;
    long long int fye_i = 0;
    long long int fze_i = 0;
#endif    
    unsigned int index = psWarp->nlEntry.NL.ypos + (tgx & cSim.NLAtomsPerWarpBitsMask);
    if (index < psWarp->nlEntry.NL.ymax) {
      PMEFloat2 xy = cSim.pAtomXYSP[index];
      PMEFloat2 qljid = cSim.pAtomChargeSPLJID[index];
      zi = cSim.pAtomZSP[index];
      xi = xy.x;
      yi = xy.y;
      qi = qljid.x;
#ifdef use_DPFP
      LJIDi = __double_as_longlong(qljid.y);
#else
      LJIDi = __float_as_uint(qljid.y);
#endif
    }
    else {
      xi = (PMEFloat)10000.0 * index;
      yi = (PMEFloat)10000.0 * index;
      zi = (PMEFloat)10000.0 * index;
      qi = (PMEFloat)0.0;
      LJIDi = 0;
    }
#ifndef PME_IS_ORTHOGONAL
    // Transform into cartesian space
#  ifdef PME_VIRIAL
    xi = sUcellf[0]*xi + sUcellf[1]*yi + sUcellf[2]*zi;
    yi =                 sUcellf[4]*yi + sUcellf[5]*zi;
    zi =                                 sUcellf[8]*zi;
#  else
    xi = cSim.ucellf[0][0]*xi + cSim.ucellf[0][1]*yi + cSim.ucellf[0][2]*zi;
    yi =                        cSim.ucellf[1][1]*yi + cSim.ucellf[1][2]*zi;
    zi =                                               cSim.ucellf[2][2]*zi;
#  endif
#endif
    // Special-case first tile: in the branch and loop that follows, each thread in a warp
    // will take the perspective of one "i" atom and loop over 8, 16, or 32 "j" atoms
    // depending on the compilation.
    if (psWarp->bHomeCell) {
      exclusion = cSim.pNLAtomList[psWarp->nlEntry.NL.offset +
                                   (tgx & cSim.NLAtomsPerWarpBitsMask)];
      __SYNCWARP(0xFFFFFFFF);
      if (tgx == 0) 
        psWarp->nlEntry.NL.offset += cSim.NLAtomsPerWarp;
      __SYNCWARP(0xFFFFFFFF);
#if (PME_ATOMS_PER_WARP == 16)
      exclusion = __SHFL_UP(0xFFFFFFFF, exclusion, 16);
      exclusion >>= 4*(tgx >> cSim.NLAtomsPerWarpBits);
#elif (PME_ATOMS_PER_WARP == 8)
      exclusion = __SHFL_UP(0xFFFFFFFF, exclusion, 16);
      exclusion = __SHFL_UP(0xFFFFFFFF, exclusion,  8);
      exclusion >>= (tgx >> cSim.NLAtomsPerWarpBits);
#endif
      // In the first tile, atoms A, B, C, ... N are interacting with each other, not
      // some new group of 8, 16, or 32 atoms.  shAtom, a buffer for each thread to
      // store its j atom in addition to its i atom, is not needed in this context.
      // However, the Lennard Jones index of each i atom gets multiplied by the total
      // number of types to prepare for indexing into the table, so store the original
      // value for future __shfl() reference.
      unsigned int LJIDj = LJIDi;
      LJIDi *= cSim.LJTypes;

      // Tile accumulators for forces, energy, and virial components
      PMEFloat TLx_i  = (PMEFloat)0.0;
      PMEFloat TLy_i  = (PMEFloat)0.0;
      PMEFloat TLz_i  = (PMEFloat)0.0;
#ifdef PME_ENERGY
      PMEFloat TLeed  = (PMEFloat)0.0;
      PMEFloat TLevdw = (PMEFloat)0.0;
#endif
#ifdef PME_VIRIAL
      PMEFloat TLvir_11 = (PMEFloat)0.0;
      PMEFloat TLvir_22 = (PMEFloat)0.0;
      PMEFloat TLvir_33 = (PMEFloat)0.0;
#endif
      // Set up iteration counts.  The first tile loop uniquely skips the
      // first interaction of particle held by each thread tgx, as it would
      // be each i atom with itself.  In subsequent tiles, the interaction
      // of the i atom in thread tgx with the j atom in that same thread
      // is necessary--they are different atoms.
      int ift;
#if (PME_ATOMS_PER_WARP < 32)
      int j = sStart[tgx];
      int jrec = sRecvStart[tgx];
#else
      int j = sNext[tgx];
      int jrec = sRecv[tgx];
#endif
#if (PME_ATOMS_PER_WARP == 32)
      const int iftlim = 16;
#elif (PME_ATOMS_PER_WARP == 16)
      const int iftlim = 4;
#elif (PME_ATOMS_PER_WARP == 8)
      const int iftlim = 1;
#endif
      for (ift = 0; ift < iftlim; ift++) {
        PMEFloat xij = xi - __SHFL(0xFFFFFFFF, xi, j);
        PMEFloat yij = yi - __SHFL(0xFFFFFFFF, yi, j);
        PMEFloat zij = zi - __SHFL(0xFFFFFFFF, zi, j);
        PMEFloat r2  = xij*xij + yij*yij + zij*zij;
        unsigned int index = LJIDi + __SHFL(0xFFFFFFFF, LJIDj, j);
        PMEFloat qiqj = qi * __SHFL(0xFFFFFFFF, qi, j);
        PMEFloat df = (PMEFloat)0.0;
        int inrange = ((r2 < cSim.cut2) && r2 > delta);
        if (inrange) {
#if defined(use_SPFP) && !defined(PME_FSWITCH) && !defined(PME_ENERGY)
          PMEFloat r2inv = (PMEFloat)1.0 / r2;
          int cidx = 2*(__float_as_int(r2) >> 18) + (exclusion & 0x1);
#  if defined(__CUDA_ARCH__) && ((__CUDA_ARCH__ == 700) || (__CUDA_ARCH__ >= 800))
          PMEFloat4 coef = cSim.pErfcCoeffsTable[cidx];
#  else
          PMEFloat4 coef = tex1Dfetch<float4>(cSim.texErfcCoeffsTable, cidx);
#  endif
#else
          PMEFloat rinv  = rsqrt(r2);
          PMEFloat r     = r2 * rinv;
          PMEFloat r2inv = rinv * rinv;
#endif
#ifndef use_DPFP
#  if defined(__CUDA_ARCH__) && ((__CUDA_ARCH__ == 700) || (__CUDA_ARCH__ >= 800))
          PMEFloat2 term = cSim.pLJTerm[index];
#  else
          PMEFloat2 term = tex1Dfetch<float2>(cSim.texLJTerm, index);
#  endif
#else
          PMEFloat2 term = cSim.pLJTerm[index];
#endif
          PMEFloat r6inv = r2inv * r2inv * r2inv;
#if defined(use_SPFP) && !defined(PME_FSWITCH) && !defined(PME_ENERGY)
          PMEFloat d_swtch_dx = r2*coef.x + coef.y + r2inv*(coef.z + r2inv*coef.w);
#else
#  ifdef use_DPFP
          PMEFloat swtch = erfc(cSim.ew_coeffSP * r);
#  else
          PMEFloat swtch = fasterfc(r);
#  endif
          PMEFloat d_swtch_dx = cSim.negTwoEw_coeffRsqrtPI * exp(-cSim.ew_coeff2 * r2);
#endif
#ifdef PME_ENERGY
          PMEFloat fnrange = (PMEFloat)inrange;
#  if (PME_ATOMS_PER_WARP == 32)
          if (ift == iftlim-1) {
            fnrange *= (PMEFloat)0.5;
          }
#  elif (PME_ATOMS_PER_WARP == 16)
          if (ift == iftlim-1 && tgx >= 16) {
            fnrange *= (PMEFloat)0.5;
          }
#  elif (PME_ATOMS_PER_WARP == 8)
          if (tgx >= 24) {
            fnrange *= (PMEFloat)0.5;
          }
#  endif
#endif
#ifdef PME_FSWITCH
          if (!(exclusion & 0x1)) {
            PMEFloat r3inv = rinv*r2inv;
            PMEFloat r12inv = r6inv*r6inv;
            PMEFloat df12f = (PMEFloat)(-1) * term.x * cSim.cut6invcut6minfswitch6 * r2inv *
                             r6inv * (r6inv - cSim.cut6inv);
            PMEFloat df6f = (PMEFloat)(-1) * term.y * cSim.cut3invcut3minfswitch3 * r3inv *
                            r2inv * (r3inv - cSim.cut3inv);
            PMEFloat df12 = (PMEFloat)(-1) * term.x * r2inv * r12inv;
            PMEFloat df6 = (PMEFloat)(-1) * term.y * r2inv * r6inv;
#  ifdef PME_ENERGY
            PMEFloat f12f = term.x * cSim.cut6invcut6minfswitch6 *
                            (r6inv - cSim.cut6inv) * (r6inv - cSim.cut6inv);
            PMEFloat f6f = term.y * cSim.cut3invcut3minfswitch3 *
                           (r3inv - cSim.cut3inv) * (r3inv - cSim.cut3inv);
            PMEFloat f12 = term.x*r12inv - term.x*cSim.invfswitch6cut6;
            PMEFloat f6 = term.y*r6inv - term.y*cSim.invfswitch3cut3;
#  endif
            if (r2 > cSim.fswitch2) {
              df12 = df12f;
              df6 = df6f;
#  ifdef PME_ENERGY
              f12 = f12f;
              f6 = f6f;
#  endif
            }
#  ifdef PME_ENERGY
            TLevdw += fnrange * (f12*twelvth - f6*sixth);
#  endif
            df += df6 - df12;
          }
#else  // PME_FSWITCH
          if (!(exclusion & 0x1)) {
            PMEFloat f6 = term.y * r6inv;
            PMEFloat f12 = term.x * r6inv * r6inv;
            df += (f12 - f6) * r2inv;
#  ifdef PME_ENERGY
            TLevdw += fnrange * (f12*twelvth - f6*sixth);
#  endif
          }
#endif // PME_FSWITCH
#if defined(use_DPFP) || defined(PME_FSWITCH) || defined(PME_ENERGY)
          else {
            swtch -= (PMEFloat)1.0;
          }
#endif
          // This ends a branch for "not an exclusion"--the non-bonded interaction is
          // to be counted.  0x1 is simply 1 in hexadecimal.

#ifdef PME_ENERGY
          PMEFloat b0 = qiqj * swtch * rinv;
          PMEFloat b1 = b0 - qiqj * d_swtch_dx;
          df += b1 * r2inv;
          TLeed += fnrange * b0;
#else  // PME_ENERGY
#  if defined(use_SPFP) && !defined(PME_FSWITCH)
          df += qiqj * d_swtch_dx;
#  else
          df += qiqj * (swtch * rinv - d_swtch_dx) * r2inv;
#  endif
#endif // PME_ENERGY
#if !defined(use_DPFP) && defined(PME_MINIMIZATION)
          df = max(-10000.0f, min(df, 10000.0f));
#endif
        }//inrange
#if (PME_ATOMS_PER_WARP == 32)
	if (ift == 15) {
	  df *= (PMEFloat)0.5;
	}
#elif (PME_ATOMS_PER_WARP == 16)
	if (ift == 3 && tgx >= 16) {
	  df *= (PMEFloat)0.5;
	}
#elif (PME_ATOMS_PER_WARP == 8)
	if (tgx >= 24) {
	  df *= (PMEFloat)0.5;
	}
#endif
        PMEFloat dfdx = df * xij;
        PMEFloat dfdy = df * yij;
        PMEFloat dfdz = df * zij;

        // Accumulate into registers for i atoms only, but accumulate
        // both the action and the equal and opposite reaction
        TLx_i += dfdx;
        TLy_i += dfdy;
        TLz_i += dfdz;
        TLx_i -= __SHFL(0xFFFFFFFF, dfdx, jrec);
        TLy_i -= __SHFL(0xFFFFFFFF, dfdy, jrec);
        TLz_i -= __SHFL(0xFFFFFFFF, dfdz, jrec);
#ifdef PME_VIRIAL
        TLvir_11 -= xij * dfdx;
        TLvir_22 -= yij * dfdy;
        TLvir_33 -= zij * dfdz;
#endif

        // Shift bits one to the right in the exclusion tracker to move on to the next atom.
        exclusion >>= 1;
        j = sNext[j];
        jrec = sRecv[jrec];
      }

      // Commit tile accumulators
#ifdef use_SPFP
      fx_i += fast_llrintf(TLx_i * FORCESCALEF);
      fy_i += fast_llrintf(TLy_i * FORCESCALEF);
      fz_i += fast_llrintf(TLz_i * FORCESCALEF);
#else
#  ifdef PME_MINIMIZATION
      PMEFloat i;
      TLx_i = modf(TLx_i, &i);
      fxe_i += llrint(i);
      TLy_i = modf(TLy_i, &i);
      fye_i += llrint(i);
      TLz_i = modf(TLz_i, &i);
      fze_i += llrint(i);
#  endif
      fx_i += llrint(TLx_i * FORCESCALE);
      fy_i += llrint(TLy_i * FORCESCALE);
      fz_i += llrint(TLz_i * FORCESCALE);
#endif

#ifdef PME_ENERGY
      // The factor of 1/2 was folded into the Lennard-Jones calculation
      // above, but not the electrostatic calculation.
#  ifdef use_SPFP
      eed  += fast_llrintf(TLeed * ENERGYSCALEF);
      evdw += fast_llrintf(TLevdw * ENERGYSCALEF);
#  else
#    ifdef PME_MINIMIZATION
      TLevdw = modf(TLevdw, &i); 
      evdwe += llrint(i);
      TLeed = modf(TLeed, &i);     
      eede += llrint(i);
#    endif
      evdw += llrint(TLevdw * ENERGYSCALE);
      eed += llrint(TLeed * ENERGYSCALE);
#  endif
#endif

#ifdef PME_VIRIAL
#  ifdef use_SPFP
      vir_11 += fast_llrintf(TLvir_11 * FORCESCALEF);
      vir_22 += fast_llrintf(TLvir_22 * FORCESCALEF);
      vir_33 += fast_llrintf(TLvir_33 * FORCESCALEF);
#  else 
#    if defined(PME_MINIMIZATION)
      TLvir_11 = modf(TLvir_11, &i);
      vir_11E += llrint(i);
      TLvir_22 = modf(TLvir_22, &i);
      vir_22E += llrint(i);     
      TLvir_33 = modf(TLvir_33, &i);
      vir_33E += llrint(i); 
#    endif
      vir_11 += llrint(TLvir_11 * FORCESCALE);
      vir_22 += llrint(TLvir_22 * FORCESCALE);
      vir_33 += llrint(TLvir_33 * FORCESCALE);
#  endif
#endif
    }//if (psWarp->bHomeCell)
    else {
      LJIDi *= cSim.LJTypes;
    }
    // This ends the branch for special-casing the first tile to have
    // 32 atoms interact with each other.  LJIDi, the LJ index for the
    // ith atom, has to be set for future operations, no matter what.

    // Handle the remainder of the line
    int tx = 0;
    while (tx < psWarp->nlEntry.NL.xatoms) {

      // Read atom ID and exclusion data
      NLAtom shAtom;
      shAtom.ID = cSim.pNLAtomList[psWarp->nlEntry.NL.offset + tgx];
      __SYNCWARP(0xFFFFFFFF);
      if (tgx == 0) 
        psWarp->nlEntry.NL.offset += GRID;
      __SYNCWARP(0xFFFFFFFF);
      exclusion = cSim.pNLAtomList[psWarp->nlEntry.NL.offset +
                                   (tgx & cSim.NLAtomsPerWarpBitsMask)];
      __SYNCWARP(0xFFFFFFFF);
      if (tgx == 0)
        psWarp->nlEntry.NL.offset += cSim.NLAtomsPerWarp;
      __SYNCWARP(0xFFFFFFFF);
#if (PME_ATOMS_PER_WARP < 32)
      exclusion >>= cSim.NLAtomsPerWarp * (tgx >> cSim.NLAtomsPerWarpBits);
#endif
      // Clear j atom forces
#ifdef use_SPFP
      PMEFloat shFx = (PMEFloat)0.0;
      PMEFloat shFy = (PMEFloat)0.0;
      PMEFloat shFz = (PMEFloat)0.0;
#else
      PMEForce shFx = (PMEForce)0;
      PMEForce shFy = (PMEForce)0;
      PMEForce shFz = (PMEForce)0;
#endif

      // Read shared memory data
      if (tx + tgx < psWarp->nlEntry.NL.xatoms) {
        unsigned int atom = shAtom.ID >> NLATOM_CELL_SHIFT;
#ifndef use_DPFP
#  if defined(__CUDA_ARCH__) && ((__CUDA_ARCH__ == 700) || (__CUDA_ARCH__ >= 800))
        PMEFloat2 xy = cSim.pAtomXYSP[atom];
        PMEFloat2 qljid = cSim.pAtomChargeSPLJID[atom];
        shAtom.z = cSim.pAtomZSP[atom];
#  else
        PMEFloat2 xy = tex1Dfetch<float2>(cSim.texAtomXYSP, atom);
        PMEFloat2 qljid = tex1Dfetch<float2>(cSim.texAtomChargeSPLJID, atom);
        shAtom.z = tex1Dfetch<float>(cSim.texAtomZSP, atom);
#  endif
#else
        PMEFloat2 xy = cSim.pAtomXYSP[atom];
        PMEFloat2 qljid = cSim.pAtomChargeSPLJID[atom];
        shAtom.z = cSim.pAtomZSP[atom];
#endif
        shAtom.x = xy.x;
        shAtom.y = xy.y;
        shAtom.q = qljid.x;
#ifdef use_DPFP
        shAtom.LJID = __double_as_longlong(qljid.y);
#else
        shAtom.LJID = __float_as_uint(qljid.y);
#endif
      }
      else {
        shAtom.x = (PMEFloat)-10000.0 * tgx;
        shAtom.y = (PMEFloat)-10000.0 * tgx;
        shAtom.z = (PMEFloat)-10000.0 * tgx;
        shAtom.q = (PMEFloat)0.0;
        shAtom.LJID = 0;
      }

      // Translate all atoms into a local coordinate system within one unit
      // cell of the first atom read to avoid PBC handling within inner loops
      int cell = shAtom.ID & NLATOM_CELL_TYPE_MASK;
#if defined(PME_VIRIAL) && defined(PME_IS_ORTHOGONAL)
      shAtom.x += sUcellf[0] * cSim.cellOffset[cell][0];
      shAtom.y += sUcellf[4] * cSim.cellOffset[cell][1];
      shAtom.z += sUcellf[8] * cSim.cellOffset[cell][2];
#else
      shAtom.x += cSim.cellOffset[cell][0];
      shAtom.y += cSim.cellOffset[cell][1];
      shAtom.z += cSim.cellOffset[cell][2];
#endif
#ifndef PME_IS_ORTHOGONAL
#  ifdef PME_VIRIAL
      shAtom.x = sUcellf[0]*shAtom.x + sUcellf[1]*shAtom.y + sUcellf[2]*shAtom.z;
      shAtom.y = sUcellf[4]*shAtom.y + sUcellf[5]*shAtom.z;
      shAtom.z = sUcellf[8]*shAtom.z;
#  else
      shAtom.x = cSim.ucellf[0][0]*shAtom.x + cSim.ucellf[0][1]*shAtom.y +
                 cSim.ucellf[0][2]*shAtom.z;
      shAtom.y = cSim.ucellf[1][1]*shAtom.y + cSim.ucellf[1][2]*shAtom.z;
      shAtom.z = cSim.ucellf[2][2]*shAtom.z;
#  endif
#endif

#ifdef PME_ENERGY
      PMEFloat TLeed  = (PMEFloat)0.0;
      PMEFloat TLevdw = (PMEFloat)0.0;
#endif
#ifdef PME_VIRIAL
      PMEFloat TLvir_11 = (PMEFloat)0.0;
      PMEFloat TLvir_22 = (PMEFloat)0.0;
      PMEFloat TLvir_33 = (PMEFloat)0.0;
#endif
      // Initialize tile-specific accumulators
      PMEFloat TLx_i  = (PMEFloat)0.0;
      PMEFloat TLy_i  = (PMEFloat)0.0;
      PMEFloat TLz_i  = (PMEFloat)0.0;
      
      // Initialize iterators: j indicates that this thread should seek out the
      // "j atom" atom owned by thread j, whereas jrec indicates that thread jrec
      // will have information to contribute to the "j atom" owned by this thread.
      int j = tgx;
      int jrec = tgx;
      if (__ANY(0xFFFFFFFF, exclusion)) {
        unsigned int mask1 = 0xFFFFFFFF;
#pragma unroll 2
        do {
          PMEFloat xij = xi - __SHFL(mask1, shAtom.x, j);
          PMEFloat yij = yi - __SHFL(mask1, shAtom.y, j);
          PMEFloat zij = zi - __SHFL(mask1, shAtom.z, j);
          PMEFloat r2  = xij*xij + yij*yij + zij*zij;
          unsigned int index = LJIDi + __SHFL(mask1, shAtom.LJID, j);
          PMEFloat qiqj = qi * __SHFL(mask1, shAtom.q, j);
	  PMEFloat df = (PMEFloat)0.0;
          int inrange = ((r2 < cSim.cut2) && r2 > delta);
          if (inrange) {
#if defined(use_SPFP) && !defined(PME_FSWITCH) && !defined(PME_ENERGY)
            PMEFloat r2inv = (PMEFloat)1.0 / r2;
            int cidx = 2*(__float_as_int(r2) >> 18) + (exclusion & 0x1);
#  if defined(__CUDA_ARCH__) && ((__CUDA_ARCH__ == 700) || (__CUDA_ARCH__ >= 800))
            PMEFloat4 coef = cSim.pErfcCoeffsTable[cidx];
#  else
            PMEFloat4 coef = tex1Dfetch<float4>(cSim.texErfcCoeffsTable, cidx);
#  endif
#else
            PMEFloat rinv      = rsqrt(r2);
            PMEFloat r         = r2 * rinv;
            PMEFloat r2inv     = rinv * rinv;
#endif
#ifndef use_DPFP
#  if defined(__CUDA_ARCH__) && ((__CUDA_ARCH__ == 700) || (__CUDA_ARCH__ >= 800))
            PMEFloat2 term = cSim.pLJTerm[index];
#  else
            PMEFloat2 term = tex1Dfetch<float2>(cSim.texLJTerm, index);
#  endif
#else
            PMEFloat2 term = cSim.pLJTerm[index];
#endif
            PMEFloat r6inv     = r2inv * r2inv * r2inv;
#if defined(use_SPFP) && !defined(PME_FSWITCH) && !defined(PME_ENERGY)
            PMEFloat d_swtch_dx = r2*coef.x + coef.y + r2inv*(coef.z + r2inv*coef.w);
#else
#  ifdef use_DPFP
            PMEFloat swtch = erfc(cSim.ew_coeffSP * r);
#  else
            PMEFloat swtch = fasterfc(r);
#  endif
            PMEFloat d_swtch_dx = cSim.negTwoEw_coeffRsqrtPI * exp(-cSim.ew_coeff2 * r2);
#endif
#ifdef PME_ENERGY
            PMEFloat fnrange = (PMEFloat)inrange;
#endif
#ifdef PME_FSWITCH
            if (!(exclusion & 0x1)) {
              PMEFloat r3inv = rinv*r2inv;
              PMEFloat r12inv = r6inv*r6inv;
              PMEFloat df12f = (PMEFloat)(-1) * term.x * cSim.cut6invcut6minfswitch6 *
                               r2inv * r6inv * (r6inv - cSim.cut6inv);
              PMEFloat df6f = (PMEFloat)(-1) * term.y * cSim.cut3invcut3minfswitch3 *
                              r3inv * r2inv * (r3inv - cSim.cut3inv);
              PMEFloat df12 = (PMEFloat)(-1) * term.x * r2inv * r12inv;
              PMEFloat df6 = (PMEFloat)(-1) * term.y * r2inv * r6inv;
#  ifdef PME_ENERGY
              PMEFloat f12f = term.x * cSim.cut6invcut6minfswitch6 *
                              (r6inv - cSim.cut6inv)*(r6inv - cSim.cut6inv);
              PMEFloat f6f = term.y * cSim.cut3invcut3minfswitch3 *
                             (r3inv - cSim.cut3inv)*(r3inv - cSim.cut3inv);
              PMEFloat f12 = (term.x * r12inv) - (term.x * cSim.invfswitch6cut6);
              PMEFloat f6 = (term.y * r6inv) - (term.y * cSim.invfswitch3cut3);
#  endif
              if (r2 > cSim.fswitch2) {
                df12 = df12f;
                df6 = df6f;
#  ifdef PME_ENERGY
                f12 = f12f;
                f6 = f6f;
#  endif
              }
              df += df6 - df12;
#  ifdef PME_ENERGY
              TLevdw += fnrange * (f12*twelvth - f6*sixth);
#  endif
            }
#else  // PME_FSWITCH
            if (!(exclusion & 0x1)) {
              PMEFloat f6 = term.y * r6inv;
              PMEFloat f12 = term.x * r6inv * r6inv;
              df += (f12 - f6) * r2inv;
#  ifdef PME_ENERGY
              TLevdw += fnrange * (f12*twelvth - f6*sixth);
#  endif
            }
#endif // PME_FSWITCH
#if defined(use_DPFP) || defined(PME_FSWITCH) || defined(PME_ENERGY)
            else {
              swtch -= (PMEFloat)1.0;
            }
#endif
#ifdef PME_ENERGY
            PMEFloat b0 = qiqj * swtch * rinv;
            PMEFloat b1 = b0 - qiqj * d_swtch_dx;
            df += b1 * r2inv;
            TLeed += fnrange * b0;
#else  // PME_ENERGY
#  if defined(use_SPFP) && !defined(PME_FSWITCH)
            df += qiqj * d_swtch_dx;
#  else
            df += qiqj*(swtch*rinv - d_swtch_dx)*r2inv;
#  endif
#endif // PME_ENERGY
#if !defined(use_DPFP) && defined(PME_MINIMIZATION)
            df = max(-10000.0f, min(df, 10000.0f));
#endif
	  }
          PMEFloat dfdx = df * xij;
          PMEFloat dfdy = df * yij;
          PMEFloat dfdz = df * zij;
          TLx_i += dfdx;
          TLy_i += dfdy;
          TLz_i += dfdz;
          shFx -= __SHFL(mask1, dfdx, jrec);
          shFy -= __SHFL(mask1, dfdy, jrec);
          shFz -= __SHFL(mask1, dfdz, jrec);
#ifdef PME_VIRIAL
          TLvir_11 -= xij * dfdx;
          TLvir_22 -= yij * dfdy;
          TLvir_33 -= zij * dfdz;
#endif          
          exclusion >>= 1;
          j = sNext[j];
          jrec = sRecv[jrec];
          mask1 = __BALLOT(mask1, j != tgx);
        } while (j != tgx);
        // End do ... while loop covering non-bonded computations when
        // there IS at least one exclusion somewhere in the pile
      }
      else {
        unsigned int mask1 = 0xFFFFFFFF;
#pragma unroll 2
        do {
          // Read properties for the other atom
          PMEFloat xij = xi - __SHFL(mask1, shAtom.x, j);
          PMEFloat yij = yi - __SHFL(mask1, shAtom.y, j);
          PMEFloat zij = zi - __SHFL(mask1, shAtom.z, j);

          // Perform the range test
          PMEFloat r2  = xij*xij + yij*yij + zij*zij;
          unsigned int index = LJIDi + __SHFL(mask1, shAtom.LJID, j);
          PMEFloat qiqj = qi * __SHFL(mask1, shAtom.q, j);
          int inrange = ((r2 < cSim.cut2) && r2 > delta);
          PMEFloat df = (PMEFloat)0.0;
          if (inrange) {
#if defined(use_SPFP) && !defined(PME_FSWITCH) && !defined(PME_ENERGY)
            PMEFloat r2inv = (PMEFloat)1.0 / r2;
            int cidx = 2 * (__float_as_int(r2) >> 18);
#  if defined(__CUDA_ARCH__) && ((__CUDA_ARCH__ == 700) || (__CUDA_ARCH__ >= 800))
            PMEFloat4 coef = cSim.pErfcCoeffsTable[cidx];
#  else
            PMEFloat4 coef = tex1Dfetch<float4>(cSim.texErfcCoeffsTable, cidx);
#  endif
#else
            PMEFloat rinv      = rsqrt(r2);
            PMEFloat r         = r2 * rinv;
            PMEFloat r2inv     = rinv * rinv;
#endif
#ifndef use_DPFP
#  if defined(__CUDA_ARCH__) && ((__CUDA_ARCH__ == 700) || (__CUDA_ARCH__ >= 800))
            PMEFloat2 term = cSim.pLJTerm[index];
#  else
            PMEFloat2 term = tex1Dfetch<float2>(cSim.texLJTerm, index);
#  endif
#else
            PMEFloat2 term = cSim.pLJTerm[index];
#endif
            PMEFloat r6inv     = r2inv * r2inv * r2inv;
#if defined(use_SPFP) && !defined(PME_FSWITCH) && !defined(PME_ENERGY)
            PMEFloat d_swtch_dx = r2*coef.x + coef.y + r2inv*(coef.z + r2inv*coef.w);
#else
#  ifdef use_DPFP
            PMEFloat swtch = erfc(cSim.ew_coeffSP * r) * rinv;
#  else
            PMEFloat swtch = fasterfc(r) * rinv;
#  endif
            PMEFloat d_swtch_dx = cSim.negTwoEw_coeffRsqrtPI * exp(-cSim.ew_coeff2 * r2);
#endif
#ifdef PME_ENERGY
            PMEFloat fnrange = (PMEFloat)inrange;
#endif
#ifdef PME_FSWITCH
            PMEFloat r3inv = rinv*r2inv;
            PMEFloat r12inv = r6inv*r6inv;
            PMEFloat df12f = (PMEFloat)(-1) * term.x * cSim.cut6invcut6minfswitch6 *
                             r2inv * r6inv * (r6inv - cSim.cut6inv);
            PMEFloat df6f = (PMEFloat)(-1) * term.y * cSim.cut3invcut3minfswitch3 *
                            r3inv * r2inv * (r3inv - cSim.cut3inv);
            PMEFloat df12 = (PMEFloat)(-1) * term.x * r2inv * r12inv;
            PMEFloat df6 = (PMEFloat)(-1) * term.y * r2inv * r6inv;
#  ifdef PME_ENERGY
            PMEFloat f12f = term.x * cSim.cut6invcut6minfswitch6 *
                            (r6inv - cSim.cut6inv)*(r6inv - cSim.cut6inv);
            PMEFloat f6f = term.y * cSim.cut3invcut3minfswitch3 *
                           (r3inv - cSim.cut3inv)*(r3inv - cSim.cut3inv);
            PMEFloat f12 = term.x * r12inv - term.x * cSim.invfswitch6cut6;
            PMEFloat f6 = term.y * r6inv - term.y * cSim.invfswitch3cut3;
#  endif
            if (r2 > cSim.fswitch2) {
              df12 = df12f;
              df6 = df6f;
#  ifdef PME_ENERGY
              f12 = f12f;
              f6 = f6f;
#  endif
            }
            df += df6 - df12;
#  ifdef PME_ENERGY
            TLevdw += fnrange * (f12*twelvth - f6*sixth);
            PMEFloat b0 = qiqj * swtch;
            PMEFloat b1 = b0 - qiqj * d_swtch_dx;
            df += b1 * r2inv;
            TLeed += fnrange * b0;
#  else  // PME_ENERGY
            df += qiqj * (swtch - d_swtch_dx) * r2inv;
#  endif // PME_ENERGY
#else // PME_FSWITCH
            PMEFloat f6 = term.y * r6inv;
            PMEFloat f12 = term.x * r6inv * r6inv;
            df += (f12-f6) * r2inv;
#  ifdef PME_ENERGY
            TLevdw += fnrange * (f12*twelvth - f6*sixth);
            PMEFloat b0 = qiqj * swtch;
            PMEFloat b1 = b0 - qiqj * d_swtch_dx;
            df += b1 * r2inv;
            TLeed += fnrange * b0;
#  else  // PME_ENERGY
#    if defined(use_SPFP) && !defined(PME_FSWITCH)
            df += qiqj * d_swtch_dx;
#    else
            df += qiqj * (swtch - d_swtch_dx) * r2inv;
#    endif
#  endif // PME_ENERGY
#endif //PME_FSWITCH
#if !defined(use_DPFP) && defined(PME_MINIMIZATION)
            df = max(-10000.0f, min(df, 10000.0f));
#endif
	  }
          PMEFloat dfdx = df * xij;
          PMEFloat dfdy = df * yij;
          PMEFloat dfdz = df * zij;
          TLx_i += dfdx;
          TLy_i += dfdy;
          TLz_i += dfdz;
          shFx -= __SHFL(mask1, dfdx, jrec);
          shFy -= __SHFL(mask1, dfdy, jrec);
          shFz -= __SHFL(mask1, dfdz, jrec);
#ifdef PME_VIRIAL
          TLvir_11 -= xij * dfdx;
          TLvir_22 -= yij * dfdy;
          TLvir_33 -= zij * dfdz;
#endif
          j = sNext[j];
          jrec = sRecv[jrec];
          mask1 = __BALLOT(mask1, j != tgx);
        } while (j != tgx);
        // Ends do ... while loop for processing a pile of non-bonded
        // interactions with no exclusions to worry about
      }
      // End branch dealing with the presence of exclusions
      // in the pile of non-bonded interactions.

#ifdef use_SPFP
      // Commit tile accumulators to registers
      fx_i += fast_llrintf(TLx_i * FORCESCALEF);
      fy_i += fast_llrintf(TLy_i * FORCESCALEF);
      fz_i += fast_llrintf(TLz_i * FORCESCALEF);
#else
#  ifdef PME_MINIMIZATION
      PMEFloat i;
      TLx_i = modf(TLx_i, &i);
      fxe_i += llrint(i);
      TLy_i = modf(TLy_i, &i);
      fye_i += llrint(i);
      TLz_i = modf(TLz_i, &i);
      fze_i += llrint(i);
#  endif
      fx_i += llrint(TLx_i * FORCESCALE);
      fy_i += llrint(TLy_i * FORCESCALE);
      fz_i += llrint(TLz_i * FORCESCALE); 
#endif

#ifdef PME_ENERGY
#  ifdef use_SPFP
      eed  += fast_llrintf(TLeed * ENERGYSCALEF);
      evdw += fast_llrintf(TLevdw * ENERGYSCALEF);
#  else
#    ifdef PME_MINIMIZATION
      TLevdw = modf(TLevdw, &i); 
      evdwe += llrint(i);
      TLeed = modf(TLeed, &i);     
      eede += llrint(i);
#    endif
      eed  += llrint(TLeed * ENERGYSCALE);
      evdw += llrint(TLevdw * ENERGYSCALE);
#  endif
#endif

#ifdef PME_VIRIAL
#  ifdef use_SPFP
      vir_11 += fast_llrintf(TLvir_11 * FORCESCALEF);
      vir_22 += fast_llrintf(TLvir_22 * FORCESCALEF);
      vir_33 += fast_llrintf(TLvir_33 * FORCESCALEF);
#  else
#    if defined(PME_MINIMIZATION)
      TLvir_11 = modf(TLvir_11, &i);
      vir_11E += llrint(i);
      TLvir_22 = modf(TLvir_22, &i);
      vir_22E += llrint(i);     
      TLvir_33 = modf(TLvir_33, &i);
      vir_33E += llrint(i); 
#    endif
      vir_11 += llrint(TLvir_11 * FORCESCALE);
      vir_22 += llrint(TLvir_22 * FORCESCALE);
      vir_33 += llrint(TLvir_33 * FORCESCALE);
#  endif
#endif
      // Dump j atom forces
      if (tx + tgx < psWarp->nlEntry.NL.xatoms) {
        int offset = (shAtom.ID >> NLATOM_CELL_SHIFT);
#ifdef use_SPFP
        atomicAdd((unsigned long long int*)&cSim.pNBForceXAccumulator[offset],
                  llitoulli(fast_llrintf(shFx * FORCESCALEF)));
        atomicAdd((unsigned long long int*)&cSim.pNBForceYAccumulator[offset],
                  llitoulli(fast_llrintf(shFy * FORCESCALEF)));
        atomicAdd((unsigned long long int*)&cSim.pNBForceZAccumulator[offset],
                  llitoulli(fast_llrintf(shFz * FORCESCALEF)));
#else // use_DPFP
#  ifdef PME_MINIMIZATION
        PMEFloat i;
        shFx = modf(shFx, &i);
        atomicAdd((unsigned long long int*)&cSim.pIntForceXAccumulator[offset],
                  llitoulli(llrint(i)));
        shFy = modf(shFy, &i);
        atomicAdd((unsigned long long int*)&cSim.pIntForceYAccumulator[offset],
                  llitoulli(llrint(i)));   
        shFz = modf(shFz, &i);
        atomicAdd((unsigned long long int*)&cSim.pIntForceZAccumulator[offset],
                  llitoulli(llrint(i)));   
#  endif
        atomicAdd((unsigned long long int*)&cSim.pNBForceXAccumulator[offset],
                  llitoulli(llrint(shFx * FORCESCALE)));
        atomicAdd((unsigned long long int*)&cSim.pNBForceYAccumulator[offset],
                  llitoulli(llrint(shFy * FORCESCALE)));
        atomicAdd((unsigned long long int*)&cSim.pNBForceZAccumulator[offset],
                  llitoulli(llrint(shFz * FORCESCALE)));
#endif
      }
      // End contingency for dumping j atom forces to global

      // Advance to next x tile
      tx += GRID;
    }

    // Reduce register forces if necessary.  For each mode, this will take advantage of
    // the overloaded __shfl functions written in ptxmacros.h to move long long ints
    // between threads within a warp.  The functionality is now found in new versions of
    // CUDA as well.  If PME_ATOMS_PER_WARP <= 16 it must be 16 or 8.  The 16-stride
    // reduction is always necessary.  An additional 8-stride reduction may be necessary.
#if (PME_ATOMS_PER_WARP <= 16)
    fx_i += __SHFL(0xFFFFFFFF, fx_i, tgx + 16);
    fy_i += __SHFL(0xFFFFFFFF, fy_i, tgx + 16);
    fz_i += __SHFL(0xFFFFFFFF, fz_i, tgx + 16);
#  if defined(use_DPFP) && defined(PME_MINIMIZATION)
    fxe_i += __SHFL(0xFFFFFFFF, fxe_i, tgx + 16);
    fye_i += __SHFL(0xFFFFFFFF, fye_i, tgx + 16);
    fze_i += __SHFL(0xFFFFFFFF, fze_i, tgx + 16);
#  endif
#  if (PME_ATOMS_PER_WARP == 8)
    fx_i += __SHFL(0xFFFFFFFF, fx_i, tgx + 8);
    fy_i += __SHFL(0xFFFFFFFF, fy_i, tgx + 8);
    fz_i += __SHFL(0xFFFFFFFF, fz_i, tgx + 8);
#    if defined(use_DPFP) && defined(PME_MINIMIZATION)
    fxe_i += __SHFL(0xFFFFFFFF, fxe_i, tgx + 8);
    fye_i += __SHFL(0xFFFFFFFF, fye_i, tgx + 8);
    fze_i += __SHFL(0xFFFFFFFF, fze_i, tgx + 8);
#    endif
#  endif
#endif // End pre-processor branch for accumulating register
       // forces with different numbers of atoms per warp

    // Dump register forces
    if (psWarp->nlEntry.NL.ypos + tgx < psWarp->nlEntry.NL.ymax) {
      int offset = psWarp->nlEntry.NL.ypos + tgx;
      atomicAdd((unsigned long long int*)&cSim.pNBForceXAccumulator[offset],
                llitoulli(fx_i));
      atomicAdd((unsigned long long int*)&cSim.pNBForceYAccumulator[offset],
                llitoulli(fy_i));
      atomicAdd((unsigned long long int*)&cSim.pNBForceZAccumulator[offset],
                llitoulli(fz_i));
#if defined(use_DPFP) && defined(PME_MINIMIZATION)
      atomicAdd((unsigned long long int*)&cSim.pIntForceXAccumulator[offset],
                llitoulli(fxe_i));
      atomicAdd((unsigned long long int*)&cSim.pIntForceYAccumulator[offset],
                llitoulli(fye_i));
      atomicAdd((unsigned long long int*)&cSim.pIntForceZAccumulator[offset],
                llitoulli(fze_i));      
#endif
    }
    // End of contingency for dumping register forces.

    // Get next Neighbor List entry
    if (tgx == 0) {
      psWarp->pos = atomicAdd(&cSim.pFrcBlkCounters[0], 1);
    }
    __SYNCWARP(0xFFFFFFFF);
  }
  // End of massive while loop iterating psWarp->pos up to sNLEntries
  
  
// Reduce virials and/or energies
#if defined(PME_VIRIAL) || defined(PME_ENERGY)
  unsigned int rlev;
  for (rlev = 16; rlev > 0; rlev /= 2) 
  {
#  ifdef PME_ENERGY
#    if defined(use_DPFP) && defined(PME_MINIMIZATION)
    eede += __SHFL(0xFFFFFFFF, eede, tgx + rlev);
    evdwe += __SHFL(0xFFFFFFFF, evdwe, tgx + rlev);
#    endif
    eed += __SHFL(0xFFFFFFFF, eed, tgx + rlev);
    evdw += __SHFL(0xFFFFFFFF, evdw, tgx + rlev);
#  endif

#  ifdef PME_VIRIAL
#    if defined(use_DPFP) && defined(PME_MINIMIZATION)
    vir_11E += __SHFL(0xFFFFFFFF, vir_11E, tgx + rlev);
    vir_22E += __SHFL(0xFFFFFFFF, vir_22E, tgx + rlev);
    vir_33E += __SHFL(0xFFFFFFFF, vir_33E, tgx + rlev);
#    endif
    vir_11 += __SHFL(0xFFFFFFFF, vir_11, tgx + rlev);
    vir_22 += __SHFL(0xFFFFFFFF, vir_22, tgx + rlev);
    vir_33 += __SHFL(0xFFFFFFFF, vir_33, tgx + rlev);
#  endif  
  }  
#endif

  

#ifdef PME_VIRIAL
  if ((threadIdx.x & GRID_BITS_MASK) == 0) {
#  if defined(use_DPFP) && defined(PME_MINIMIZATION)
    atomicAdd(cSim.pVirial_11E, llitoulli(vir_11E));
    atomicAdd(cSim.pVirial_22E, llitoulli(vir_22E));
    atomicAdd(cSim.pVirial_33E, llitoulli(vir_33E));
#  endif
    atomicAdd(cSim.pVirial_11, llitoulli(vir_11));
    atomicAdd(cSim.pVirial_22, llitoulli(vir_22));
    atomicAdd(cSim.pVirial_33, llitoulli(vir_33));
  }
#endif

#ifdef PME_ENERGY
  if ((threadIdx.x & GRID_BITS_MASK) == 0) {
    atomicAdd(cSim.pEVDW, llitoulli(evdw));
    atomicAdd(cSim.pEED, llitoulli(eed));
#  if defined(use_DPFP) && defined(PME_MINIMIZATION)
    atomicAdd(cSim.pEVDWE, llitoulli(evdwe));
    atomicAdd(cSim.pEEDE, llitoulli(eede));
#  endif
  }
#endif // PME_ENERGY
}
